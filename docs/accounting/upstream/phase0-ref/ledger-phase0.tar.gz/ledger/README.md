# Phase 0 — walking skeleton

A runnable ledger core for a multi-tenant SaaS accounting platform. It exists to
prove the decisions that are expensive-to-impossible to reverse, before anyone
builds a UI on top of them.

**Exit criterion, from the blueprint:** you can post, reverse, close a period,
produce a trial balance, and *prove isolation in CI*. No UI required.

That criterion is met. 72 tests, green.

---

## Run it

```bash
createdb ledger
cp .env.example .env && $EDITOR .env && source .env
make db            # migrate + seed two demo tenants
make test          # 72 tests
make gate          # CI gates standalone — exits 1 on any finding
```

Requires PostgreSQL 16+ and Python 3.11+. `docker-compose.yml` brings up
PostgreSQL 18 and PgBouncer in transaction pooling mode if you'd rather not use
a local cluster.

---

## What is actually proven here

Not "written down" — asserted by a test that fails if you break it.

### Tenant isolation

| Test | Proves |
|---|---|
| `test_tenant_sees_only_own_accounts` | The positive case |
| `test_no_tenant_context_yields_zero_rows_fresh_connection` | Missing context fails **closed**, on every one of the 10 tenant tables |
| `test_no_tenant_context_yields_zero_rows_recycled_connection` | …and on a **recycled** backend too, where the GUC is `''` rather than NULL. This is the case that makes a missing `NULLIF` produce zero rows on cold connections and 500s on warm ones |
| `test_hostile_guc_value_is_inert` | `' OR true--` in the GUC raises, never returns rows |
| `test_cross_tenant_insert_rejected` | `WITH CHECK` blocks planting a row in another tenant |
| `test_cross_tenant_read_by_id_is_silent` | Reading a known foreign id returns nothing — silently, so the app must handle it |
| `test_restrictive_floor_survives_a_rogue_permissive_policy` | Someone adds `CREATE POLICY … USING (true)` to fix a ticket. Under a permissive-only design that exposes every tenant. It cannot here |
| `test_owner_is_bound_by_force_rls` | `FORCE ROW LEVEL SECURITY` — the table owner is scoped too |
| `test_reporting_role_can_actually_read` | The regression for the defect the blueprint review caught: restrictive policies only *subtract*, so `app_reports` needs its own permissive policy or every report is silently empty |
| `test_cross_tenant_foreign_key_is_structurally_impossible` | Composite FKs including `tenant_id` |
| `test_unique_constraints_are_tenant_scoped` | Constraints bypass RLS by design; a global unique index is a covert channel |
| `test_direct_partition_access_is_denied` | A query against a partition uses *that partition's* RLS state |

### Ledger correctness

| Test | Proves |
|---|---|
| `test_unbalanced_journal_rejected_by_database` | The deferred constraint trigger catches an unbalanced journal inserted with **raw SQL**, bypassing the application entirely |
| `test_deleting_a_draft_line_cannot_leave_it_unbalanced` | `DELETE` is in the trigger event list. Without it, removing a line from a draft in a later transaction leaves it permanently unbalanced, silently |
| `test_single_line_journal_rejected_at_post` | A zero- or one-line journal never fires a `FOR EACH ROW` trigger, so this is enforced at post |
| `test_posted_journal_is_immutable` / `…cannot_be_deleted_even_by_owner` | Sealed means sealed |
| `test_reversal_is_a_new_journal_not_an_edit` | Storno: the original survives, the pair nets to zero |
| `test_hash_chain_links_successive_postings` | Immutability is demonstrable, not merely claimed |
| `test_multicurrency_journal_balances_per_currency` | A EUR sale in an MYR-functional entity balances in EUR on the transaction side and MYR on the functional side |
| `test_trial_balance_balances_and_matches_the_lines` | Debits == credits, and the balance cube agrees with the lines it derives from |
| `test_outbox_row_written_in_the_same_transaction` | A side effect enqueued with the posting can never be lost |

### Numbering and periods

| Test | Proves |
|---|---|
| `test_numbers_are_zero_padded_not_space_padded` | `format('%06s')` pads with **spaces** — `PAD/2026/     1`. Regression for a real defect |
| `test_first_document_of_a_new_series_is_not_silently_dropped` | A bare `UPDATE` on the counter matches zero rows for a new series/year; the CTE yields nothing, the INSERT no-ops, and **the transaction commits successfully**. The upsert prevents it |
| `test_concurrent_numbering_has_no_gaps_or_duplicates` | Six threads racing one series: 1–6, no gaps, no duplicates |
| `test_numbering_is_per_tenant` | Tenant A's counter never blocks or bleeds into B's |
| `test_voided_document_keeps_its_number` | Reversal preserves gaplessness; deletion is what creates gaps |
| `test_cannot_post_into_a_closed_period` | Enforced by a trigger, so a data-fix script cannot bypass it |
| `test_hard_close_is_a_one_way_door` | Statutory inalterability |
| `test_reopening_marks_downstream_periods_for_recompute` | Reopening invalidates downstream snapshots instead of leaving stale openings |

### Money

`test_zero_decimal_currencies`, `test_three_decimal_currencies`,
`test_rounding_is_half_up_not_bankers`, `test_allocation_of_awkward_amounts_never_loses_a_cent`
(1,000 × 4 exhaustive cases). JPY has no minor unit; KWD has three. Anything
that divides by 100 is broken.

---

## Layout

```
db/migrations/   forward-only SQL. The ledger core stays as reviewed SQL even
                 after Django arrives — composite PKs, partitioning and
                 constraint triggers sit outside what an autodetector can express.
db/ci/           the gates. Run standalone via `make gate`, and as tests.
src/ledger/
  db.py          the tenant session wrapper — the single most important control
  money.py       Money value object; minor units, rounding policy, allocation
  posting.py     the only writer of journal lines
  periods.py     three lock tiers; roll-forward on close
  reports.py     trial balance, drift detection
  seed.py        two structurally identical demo tenants
tests/           72 tests
```

## Deliberately absent

Phase 0 contains only what cannot be added later. Not here, by design:

- **Any HTTP surface or UI.** Add Django in Phase 1 for models, admin, auth and
  the non-ledger tables. Note the cost the blueprint flags: composite primary
  keys mean `journal`, `journal_line` and `period_balance` cannot be registered
  in the Django admin, so budget a purpose-built inspection view.
- **The SLA rule engine.** Postings are hand-built here; Phase 1 makes account
  derivation data.
- **AR/AP, banking, inventory, fixed assets, revenue recognition.**
- **Localisation packs**, e-invoicing, tax determination, statutory exports.
- **The dimensional cube maintenance.** `period_balance_dim` and
  `dimension_tuple` exist in the schema so the shape is right; only the
  account-level trial-balance cube is maintained.

## Known simplifications

- `app.uuid7()` is a plpgsql shim so this runs on PostgreSQL 16. On 18, replace
  the body with `SELECT uuidv7()`.
- Partitioning is `LIST (tenant_id)` with a single DEFAULT partition. Whale
  partitions are a provisioning step; sub-partitioning by `effective_date` would
  require `effective_date` in every primary key, which cascades into every
  composite FK — decide that before you have data, not after.
- The control plane shares a database here so the skeleton runs on one
  connection string. In production it is separate.
- `close_period` derives the year-end close rather than physically zeroing P&L
  accounts. France's PCG requires a real *clôture* into account 12 — that is a
  localisation-pack override, not a law, and the hook is `close_pnl`.
