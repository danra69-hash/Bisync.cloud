"""Tenant isolation.

The four tests every tenant table needs, plus the regressions for the specific
failures that make RLS designs leak or silently break. Blueprint §2.9.
"""

from __future__ import annotations

import os
import uuid

import psycopg
import pytest

from ledger.db import _dsn, tenant_session, admin_session

TENANT_TABLES = [
    "entity", "ledger", "account", "fiscal_period", "doc_counter",
    "journal", "journal_line", "period_balance", "outbox", "audit_event",
]


# ── 1. Positive: tenant A sees exactly A's rows ──────────────────────────────
def test_tenant_sees_only_own_accounts(acme, globex):
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT tenant_id FROM app.account")
        seen = {r["tenant_id"] for r in cur.fetchall()}
    assert seen == {acme["tenant_id"]}
    assert globex["tenant_id"] not in seen


# ── 2. No context: zero rows, no error, no leak ──────────────────────────────
@pytest.mark.parametrize("table", TENANT_TABLES)
def test_no_tenant_context_yields_zero_rows_fresh_connection(schema, table):
    """A fresh backend: current_setting() returns NULL."""
    with psycopg.connect(_dsn("app_rw"), autocommit=False) as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT count(*) FROM app.{table}")
            assert cur.fetchone()[0] == 0


@pytest.mark.parametrize("table", TENANT_TABLES)
def test_no_tenant_context_yields_zero_rows_recycled_connection(acme, table):
    """A RECYCLED backend behaves differently, and this is the whole reason for NULLIF.

    Once a GUC has been defined in a session it stays defined as '' after the
    transaction-local value expires. Without NULLIF, ''::uuid RAISES — so the
    same bug is zero rows on cold connections and 500s on warm ones:
    intermittent, load-dependent, and maddening to reproduce.
    """
    with psycopg.connect(_dsn("app_rw"), autocommit=False) as conn:
        with conn.cursor() as cur:
            # transaction 1: with context
            cur.execute("SELECT set_config('app.tenant_id', %s, true)",
                        (str(acme["tenant_id"]),))
            cur.execute(f"SELECT count(*) FROM app.{table}")
            conn.commit()
            # transaction 2: same backend, context expired -> GUC is now ''
            cur.execute("SELECT current_setting('app.tenant_id', true) AS v")
            assert cur.fetchone()[0] == ""          # not NULL — this is the trap
            cur.execute(f"SELECT count(*) FROM app.{table}")
            assert cur.fetchone()[0] == 0           # fails CLOSED, does not raise
            conn.commit()


def test_hostile_guc_value_is_inert(schema):
    """SQL-injection-shaped input in the GUC yields an error, never rows."""
    with psycopg.connect(_dsn("app_rw"), autocommit=False) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('app.tenant_id', %s, true)", ("' OR true--",))
            with pytest.raises(psycopg.errors.InvalidTextRepresentation):
                cur.execute("SELECT count(*) FROM app.journal")


# ── 3. Cross-tenant write is rejected ────────────────────────────────────────
def test_cross_tenant_insert_rejected(acme, globex):
    with pytest.raises(psycopg.errors.InsufficientPrivilege):
        with tenant_session(acme["tenant_id"]) as cur:
            cur.execute(
                """INSERT INTO app.account (tenant_id, code, name, type, normal_balance)
                   VALUES (%s, 'HACK', 'planted', 'asset', 'D')""",
                (globex["tenant_id"],))


# ── 4. Cross-tenant read-through by primary key is silent, not an error ──────
def test_cross_tenant_read_by_id_is_silent(acme, globex):
    victim = globex["accounts"]["1000"]
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT * FROM app.account WHERE id = %s", (victim,))
        assert cur.fetchall() == []     # zero rows, no exception


# ── Regressions for the specific ways this design breaks ─────────────────────
def test_reporting_role_can_actually_read(acme):
    """REGRESSION: restrictive policies only SUBTRACT.

    With only the app_rw permissive policy, app_reports sees zero rows on every
    table — every report is empty and nobody notices, because empty is exactly
    what a correctly-isolated query looks like.
    """
    with tenant_session(acme["tenant_id"], role="app_reports") as cur:
        cur.execute("SELECT count(*) AS n FROM app.account")
        assert cur.fetchone()["n"] == len(acme["accounts"])


def test_reporting_role_cannot_write(acme):
    with pytest.raises(psycopg.errors.InsufficientPrivilege):
        with tenant_session(acme["tenant_id"], role="app_reports") as cur:
            cur.execute(
                """INSERT INTO app.account (tenant_id, code, name, type, normal_balance)
                   VALUES (%s, 'RO', 'nope', 'asset', 'D')""",
                (acme["tenant_id"],))


def test_owner_is_bound_by_force_rls(acme, globex):
    """FORCE ROW LEVEL SECURITY: even the table owner is tenant-scoped."""
    from ledger.db import owner_session
    with owner_session(tenant_id=acme["tenant_id"]) as cur:
        cur.execute("SELECT DISTINCT tenant_id FROM app.account")
        assert {r["tenant_id"] for r in cur.fetchall()} == {acme["tenant_id"]}


def test_unique_constraints_are_tenant_scoped(acme, globex):
    """Constraints bypass RLS BY DESIGN — a global unique index is a covert channel.

    Both tenants use account code '1000'. If that constraint were global, the
    second tenant's provisioning would fail with an error naming the first
    tenant's row.
    """
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT code FROM app.account WHERE id = %s", (acme["accounts"]["1000"],))
        a = cur.fetchone()["code"]
    with tenant_session(globex["tenant_id"]) as cur:
        cur.execute("SELECT code FROM app.account WHERE id = %s", (globex["accounts"]["1000"],))
        b = cur.fetchone()["code"]
    assert a == b == "1000"


def test_cross_tenant_foreign_key_is_structurally_impossible(acme, globex):
    """Composite FKs including tenant_id make a cross-tenant reference impossible,
    rather than merely unobserved."""
    from ledger.db import owner_session
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        # app_owner is used so the failure is the FK, not the RLS WITH CHECK.
        with owner_session(tenant_id=acme["tenant_id"]) as cur:
            cur.execute(
                """INSERT INTO app.ledger (tenant_id, entity_id, kind, name)
                   VALUES (%s, %s, 'tax', 'cross-tenant ledger')""",
                (acme["tenant_id"], globex["entity_id"]))


def test_restrictive_floor_survives_a_rogue_permissive_policy(acme, globex):
    """The reason the floor is RESTRICTIVE rather than just permissive.

    Simulates the future engineer who adds `CREATE POLICY admin_all ... USING
    (true)` to fix a support ticket. Permissive policies OR together, so under a
    permissive-only design that one line silently exposes every tenant. With a
    restrictive floor AND-ed on top, it cannot.
    """
    with admin_session() as cur:
        cur.execute("SET ROLE app_owner")
        cur.execute("CREATE POLICY rogue_admin_all ON app.account "
                    "FOR ALL TO app_rw USING (true) WITH CHECK (true)")
    try:
        with tenant_session(acme["tenant_id"]) as cur:
            cur.execute("SELECT DISTINCT tenant_id FROM app.account")
            seen = {r["tenant_id"] for r in cur.fetchall()}
        assert seen == {acme["tenant_id"]}
        assert globex["tenant_id"] not in seen
    finally:
        with admin_session() as cur:
            cur.execute("SET ROLE app_owner")
            cur.execute("DROP POLICY rogue_admin_all ON app.account")


def test_no_tenant_session_without_a_tenant():
    """The app layer fails LOUDLY where the database fails silently."""
    from ledger.db import NoTenantContext
    with pytest.raises(NoTenantContext):
        with tenant_session(None):
            pass


def test_truncate_not_granted(schema):
    with admin_session() as cur:
        cur.execute(
            """SELECT count(*) AS n FROM information_schema.role_table_grants
                WHERE privilege_type='TRUNCATE' AND table_schema='app'
                  AND grantee IN ('app_rw','app_reports')""")
        assert cur.fetchone()["n"] == 0
