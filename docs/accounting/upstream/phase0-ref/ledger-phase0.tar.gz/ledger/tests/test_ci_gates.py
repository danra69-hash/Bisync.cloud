"""The CI gates, run as tests.

In CI these also run standalone via `make gate` so a schema change is blocked
before it merges, independently of whether anyone wrote a test for the new
table.
"""

from __future__ import annotations

import pathlib

import pytest

from ledger.db import admin_session

CI_DIR = pathlib.Path(__file__).resolve().parents[1] / "db" / "ci"


def _run_gate(filename: str) -> list[dict]:
    """Execute a gate file statement by statement; any returned row is a failure."""
    body = (CI_DIR / filename).read_text()
    statements = [s.strip() for s in body.split(";") if s.strip()
                  and not s.strip().startswith("\\")]
    findings: list[dict] = []
    with admin_session() as cur:
        for stmt in statements:
            stmt = "\n".join(l for l in stmt.splitlines() if not l.strip().startswith("\\"))
            if not stmt.strip():
                continue
            cur.execute(stmt)
            if cur.description:
                findings.extend(cur.fetchall())
    return findings


def test_every_tenant_table_has_forced_rls_and_a_restrictive_floor(schema):
    findings = _run_gate("gate_rls.sql")
    assert findings == [], f"tables without a proper RLS floor: {findings}"


def test_no_bypass_roles_no_leakproof_functions_no_matviews(schema):
    findings = _run_gate("gate_roles.sql")
    assert findings == [], f"role/index/view findings: {findings}"


def test_gate_actually_catches_an_unprotected_table(schema):
    """A gate nobody has seen fail is a gate nobody should trust."""
    with admin_session() as cur:
        cur.execute("SET ROLE app_owner")
        cur.execute("CREATE TABLE app._gate_canary (tenant_id uuid NOT NULL, x int)")
    try:
        findings = _run_gate("gate_rls.sql")
        assert any(f["table_name"] == "_gate_canary" for f in findings)
    finally:
        with admin_session() as cur:
            cur.execute("SET ROLE app_owner")
            cur.execute("DROP TABLE app._gate_canary")


def test_partitions_individually_carry_rls(schema):
    """A query issued directly against a partition uses that partition's own RLS
    state — policies on the parent are not inherited for that path."""
    with admin_session() as cur:
        cur.execute(
            """SELECT c.relname, c.relrowsecurity, c.relforcerowsecurity,
                      (SELECT count(*) FROM pg_policy p WHERE p.polrelid = c.oid) AS n_policies
                 FROM pg_inherits i
                 JOIN pg_class c ON c.oid = i.inhrelid
                 JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'app' AND c.relkind IN ('r','p')""")
        parts = cur.fetchall()
    assert parts, "expected at least one partition"
    for p in parts:
        # Enabled + forced with ZERO policies is default-deny: a direct query
        # against the partition returns nothing for every role. That is the
        # fail-closed outcome we want; access goes through the parent.
        assert p["relrowsecurity"] and p["relforcerowsecurity"], p
        assert p["n_policies"] == 0, p


def test_direct_partition_access_is_denied(acme, actor):
    """Belt and braces on the above: prove it, don't just assert the catalog."""
    from ledger.db import tenant_session
    from ledger.posting import post
    from conftest import make_draft

    post(acme["tenant_id"], make_draft(acme, series="PART"), actor)
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT count(*) AS n FROM app.journal")            # via parent
        via_parent = cur.fetchone()["n"]
        cur.execute("SELECT count(*) AS n FROM app.journal_default")    # direct
        direct = cur.fetchone()["n"]
    assert via_parent > 0
    assert direct == 0
