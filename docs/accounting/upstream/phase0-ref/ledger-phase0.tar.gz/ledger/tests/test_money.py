"""Money value object: minor units, rounding policy, exhaustive allocation."""

from __future__ import annotations

from decimal import Decimal

import pytest

from ledger.money import CurrencyMismatch, Money


def test_zero_decimal_currencies():
    """JPY has no minor unit. Anything that divides by 100 is broken here."""
    assert Money.parse("1000", "JPY").minor == 1000
    assert Money.parse("1000", "USD").minor == 100_000


def test_three_decimal_currencies():
    """KWD, BHD, OMR, TND are base-1000."""
    assert Money.parse("1.234", "KWD").minor == 1234
    assert str(Money(1234, "KWD")) == "1.234 KWD"


def test_rounding_is_half_up_not_bankers():
    """Python's decimal default is ROUND_HALF_EVEN, which surprises accountants.
    Rounding mode is policy, never a language default."""
    assert Money.parse("0.125", "USD").minor == 13     # HALF_UP; banker's gives 12
    assert Money.parse("0.135", "USD").minor == 14


def test_currency_mismatch_is_an_error_not_a_coercion():
    with pytest.raises(CurrencyMismatch):
        Money(100, "USD") + Money(100, "EUR")


def test_allocation_is_exhaustive():
    """The classic bug: round(total/n) per part creates or destroys money."""
    parts = Money(100, "USD").allocate([1, 1, 1])
    assert [p.minor for p in parts] == [34, 33, 33]
    assert sum(p.minor for p in parts) == 100


def test_allocation_by_ratio_is_exhaustive():
    parts = Money(1_000_00, "USD").allocate([3, 7])
    assert sum(p.minor for p in parts) == 1_000_00
    assert [p.minor for p in parts] == [30_000, 70_000]


def test_allocation_of_awkward_amounts_never_loses_a_cent():
    for total in range(0, 1000):
        for n in (2, 3, 7, 11):
            parts = Money(total, "USD").allocate([1] * n)
            assert sum(p.minor for p in parts) == total


def test_negative_allocation_is_exhaustive_too():
    parts = Money(-100, "USD").allocate([1, 1, 1])
    assert sum(p.minor for p in parts) == -100


def test_conversion_uses_an_explicit_directional_rate():
    """Inverted-rate bugs are endemic, so the rate is never inferred."""
    eur = Money(1_000_00, "EUR")
    myr = eur.convert("MYR", Decimal("4.85"))
    assert myr.minor == 4_850_00 and myr.currency == "MYR"


def test_conversion_into_a_zero_decimal_currency_quantises_once():
    usd = Money(10_00, "USD")                      # 10.00
    jpy = usd.convert("JPY", Decimal("151.37"))
    assert jpy.minor == 1514 and jpy.currency == "JPY"
