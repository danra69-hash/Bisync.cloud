from __future__ import annotations

import os
import sys
import pathlib
from datetime import date

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from ledger import migrate, seed  # noqa: E402
from ledger.db import admin_session  # noqa: E402


def pytest_configure(config):
    for var in ("LEDGER_DSN_ADMIN", "LEDGER_DSN_RW", "LEDGER_DSN_REPORTS"):
        if not os.environ.get(var):
            pytest.exit(f"{var} not set — see .env.example", returncode=2)


@pytest.fixture(scope="session")
def schema():
    """Rebuild the schema from scratch so the suite is deterministic.

    Gapless numbering makes tests order- and history-sensitive by construction:
    'the first document in this series is number 1' is only meaningful against a
    known starting state. Set LEDGER_TEST_RESET=0 to run against an existing
    database (useful when poking at a failure by hand).
    """
    if os.environ.get("LEDGER_TEST_RESET", "1") != "0":
        with admin_session() as cur:
            cur.execute("DROP SCHEMA IF EXISTS app, control, ref CASCADE")
            cur.execute("DROP TABLE IF EXISTS public.schema_migration")
    migrate.apply_all(verbose=False)
    return True


@pytest.fixture(scope="session")
def demo(schema):
    """Two tenants with structurally identical fixtures, different values.

    Structurally identical is the point: a leak then shows up as recognisable
    foreign data rather than as a plausible-looking row.
    """
    return seed.seed_demo(year=2026)


@pytest.fixture
def acme(demo):
    return demo["acme"]


@pytest.fixture
def globex(demo):
    return demo["globex"]


@pytest.fixture
def actor():
    from uuid import uuid4
    return uuid4()


@pytest.fixture
def jan(acme):
    return acme["periods"][1]


def make_draft(t, period_no=1, amount=100_000, series="SALES", day=15, **kw):
    """A minimal balanced sale: Dr AR / Cr Revenue."""
    from ledger.money import Money
    from ledger.posting import JournalDraft, Line
    ccy = t["currency"]
    return JournalDraft(
        entity_id=t["entity_id"], ledger_id=t["ledger_id"],
        period_id=t["periods"][period_no], journal_type="SALES",
        doc_series=series, fiscal_year=t["year"],
        effective_date=date(t["year"], period_no, day),
        document_date=date(t["year"], period_no, day),
        lines=[
            Line(t["accounts"]["1100"], "D", Money(amount, ccy)),
            Line(t["accounts"]["4000"], "C", Money(amount, ccy)),
        ],
        **kw,
    )
