"""Gapless numbering and period locking."""

from __future__ import annotations

import re
import threading
from datetime import date

import psycopg
import pytest

from ledger.db import tenant_session
from ledger.periods import PeriodError, close_period, set_status
from ledger.posting import post
from ledger.reports import trial_balance, trial_balance_totals

from conftest import make_draft


def test_numbers_are_zero_padded_not_space_padded(acme, actor):
    """REGRESSION: format()'s width flag pads with SPACES.

    '%06s' yields 'PAD/2026/     1'. This string is a legally significant
    artefact in France, Italy, Spain, Poland, Brazil and India — and spaces also
    break the string ordering of the very sequence you are proving is gapless.
    """
    r = post(acme["tenant_id"], make_draft(acme, series="PAD"), actor)
    assert " " not in r["doc_number"]
    assert re.fullmatch(r"PAD/2026/\d{6}", r["doc_number"])


def test_first_document_of_a_new_series_is_not_silently_dropped(acme, actor):
    """REGRESSION: a bare UPDATE on doc_counter matches zero rows for a brand-new
    (tenant, series, year). The CTE then yields nothing, the INSERT is a no-op,
    and the transaction COMMITS SUCCESSFULLY — a fiscal year rolls over and
    postings vanish with no error. The upsert is what prevents this."""
    r = post(acme["tenant_id"], make_draft(acme, series="BRANDNEW"), actor)
    assert r["doc_number"] == "BRANDNEW/2026/000001"
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute(
            "SELECT count(*) AS n FROM app.journal WHERE doc_series='BRANDNEW' AND posted_at IS NOT NULL")
        assert cur.fetchone()["n"] == 1


def test_numbering_is_gapless_and_sequential(acme, actor):
    numbers = [post(acme["tenant_id"], make_draft(acme, series="SEQ", amount=100 * i), actor)
               ["doc_number"] for i in range(1, 6)]
    suffixes = [int(n.split("/")[-1]) for n in numbers]
    assert suffixes == list(range(1, 6))


def test_numbering_is_per_tenant(acme, globex, actor):
    """Tenant A's counter never blocks or bleeds into tenant B's."""
    a = post(acme["tenant_id"], make_draft(acme, series="SHARED"), actor)
    b = post(globex["tenant_id"], make_draft(globex, series="SHARED"), actor)
    assert a["doc_number"] == b["doc_number"] == "SHARED/2026/000001"


def test_concurrent_numbering_has_no_gaps_or_duplicates(acme, actor):
    """Two writers racing on the same series. The counter row lock serialises
    them; because it is scoped to (tenant, series, year), it does not serialise
    anything else in the system."""
    results: list[str] = []
    errors: list[Exception] = []

    def worker(i: int):
        try:
            r = post(acme["tenant_id"], make_draft(acme, series="RACE", amount=100 + i), actor)
            results.append(r["doc_number"])
        except Exception as e:      # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, errors
    suffixes = sorted(int(n.split("/")[-1]) for n in results)
    assert suffixes == list(range(1, 7))            # no gaps
    assert len(set(results)) == len(results)        # no duplicates


def test_voided_document_keeps_its_number(acme, actor):
    """Reversal preserves gaplessness. Deleting is what creates a gap — which is
    why deletion is impossible post-numbering."""
    from ledger.posting import reverse
    orig = post(acme["tenant_id"], make_draft(acme, series="VOID"), actor)
    reverse(acme["tenant_id"], orig["journal_id"], acme["periods"][1],
            date(2026, 1, 25), actor)
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute(
            "SELECT doc_number FROM app.journal WHERE doc_series='VOID' ORDER BY doc_number")
        nums = [r["doc_number"] for r in cur.fetchall()]
    assert nums == ["VOID/2026/000001", "VOID/2026/000002"]


# ── Periods ──────────────────────────────────────────────────────────────────
def test_cannot_post_into_a_future_period(acme, actor):
    with pytest.raises(psycopg.errors.CheckViolation, match="will not accept postings"):
        post(acme["tenant_id"], make_draft(acme, period_no=6, day=1), actor)


def test_cannot_post_into_a_closed_period(acme, actor):
    period = acme["periods"][2]
    set_status(acme["tenant_id"], period, "closing", actor)
    set_status(acme["tenant_id"], period, "closed", actor)
    try:
        with pytest.raises(psycopg.errors.CheckViolation, match="will not accept postings"):
            post(acme["tenant_id"], make_draft(acme, period_no=2, day=14), actor)
    finally:
        set_status(acme["tenant_id"], period, "open", actor)


def test_effective_date_must_fall_inside_its_period(acme, actor):
    d = make_draft(acme, period_no=1)
    d.effective_date = date(2026, 3, 1)     # period 1 is January
    with pytest.raises(psycopg.errors.CheckViolation, match="outside period"):
        post(acme["tenant_id"], d, actor)


def test_hard_close_is_a_one_way_door(globex, actor):
    period = globex["periods"][3]
    set_status(globex["tenant_id"], period, "closing", actor)
    set_status(globex["tenant_id"], period, "closed", actor)
    set_status(globex["tenant_id"], period, "hard_closed", actor)
    with pytest.raises(PeriodError, match="cannot move period from hard_closed"):
        set_status(globex["tenant_id"], period, "open", actor)


def test_closing_rolls_balance_sheet_openings_forward(globex, actor):
    """Balance-sheet accounts carry forward; P&L accounts do not.

    Note what this does NOT do: physically zero the P&L accounts. Deriving the
    close is the default, but France's PCG requires a real clôture into
    account 12 — so this is a localisation-pack override, not a law.
    """
    t = globex
    post(t["tenant_id"], make_draft(t, period_no=1, amount=500_00, series="CF", day=9), actor)

    # Closing balance of period 1, taken from the ledger itself rather than a
    # magic number — the assertion is that the roll-forward is faithful, not
    # that some constant matches.
    with tenant_session(t["tenant_id"]) as cur:
        cur.execute(
            """SELECT sum(pb.opening_func_dr + pb.period_func_dr) AS dr,
                      sum(pb.opening_func_cr + pb.period_func_cr) AS cr
                 FROM app.period_balance pb
                 JOIN app.account a ON a.tenant_id=pb.tenant_id AND a.id=pb.account_id
                WHERE pb.tenant_id=%s AND pb.period_id=%s AND a.code='1100'""",
            (t["tenant_id"], t["periods"][1]))
        closing = cur.fetchone()
    expected = (int(closing["dr"]), int(closing["cr"]))
    assert expected[0] > 0

    close_period(t["tenant_id"], t["periods"][1], actor)

    with tenant_session(t["tenant_id"]) as cur:
        cur.execute(
            """SELECT a.code, pb.opening_func_dr, pb.opening_func_cr
                 FROM app.period_balance pb
                 JOIN app.account a ON a.tenant_id=pb.tenant_id AND a.id=pb.account_id
                WHERE pb.tenant_id=%s AND pb.period_id=%s
                ORDER BY a.code""",
            (t["tenant_id"], t["periods"][2]))
        openings = {r["code"]: (r["opening_func_dr"], r["opening_func_cr"])
                    for r in cur.fetchall()}

    assert openings["1100"] == expected        # AR: balance sheet, carries forward
    assert "4000" not in openings              # Revenue: P&L, does not

    with tenant_session(t["tenant_id"]) as cur:
        cur.execute("SELECT bool_and(is_frozen) AS f FROM app.period_balance "
                    "WHERE tenant_id=%s AND period_id=%s", (t["tenant_id"], t["periods"][1]))
        assert cur.fetchone()["f"] is True


def test_reopening_marks_downstream_periods_for_recompute(globex, actor):
    """Reopening a period invalidates every downstream snapshot. Without this,
    the next period silently keeps stale opening balances."""
    t = globex
    set_status(t["tenant_id"], t["periods"][1], "open", actor)
    with tenant_session(t["tenant_id"]) as cur:
        cur.execute(
            """SELECT count(*) AS n FROM app.period_balance
                WHERE tenant_id=%s AND period_id=%s AND recompute_after IS NOT NULL""",
            (t["tenant_id"], t["periods"][2]))
        assert cur.fetchone()["n"] > 0
