"""The ledger core: balance, immutability, reversal, drift."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import psycopg
import pytest

from ledger.db import tenant_session, owner_session
from ledger.money import Money
from ledger.posting import JournalDraft, Line, PostingError, post, reverse
from ledger.reports import balance_drift, trial_balance, trial_balance_totals

from conftest import make_draft


def test_post_a_balanced_journal(acme, actor):
    r = post(acme["tenant_id"], make_draft(acme, amount=250_00), actor)
    assert r["doc_number"].startswith("SALES/2026/")
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT posted_at, row_hash FROM app.journal WHERE id=%s",
                    (r["journal_id"],))
        j = cur.fetchone()
    assert j["posted_at"] is not None
    assert j["row_hash"] is not None


def test_unbalanced_journal_rejected_by_application(acme, actor):
    d = make_draft(acme)
    d.lines[1].amount = Money(999_00, acme["currency"])
    with pytest.raises(PostingError, match="unbalanced in transaction currency"):
        post(acme["tenant_id"], d, actor)


def test_unbalanced_journal_rejected_by_database(acme, actor):
    """Bypass the application check entirely — the database must still refuse.

    This is the one that matters: a bad migration script or an admin fixing data
    by hand does not go through your Python.
    """
    ccy = acme["currency"]
    with pytest.raises(psycopg.errors.CheckViolation, match="unbalanced"):
        with tenant_session(acme["tenant_id"]) as cur:
            cur.execute(
                """INSERT INTO app.journal
                     (tenant_id, entity_id, ledger_id, period_id, journal_type,
                      doc_series, fiscal_year, effective_date, document_date,
                      source_module, created_by)
                   VALUES (%s,%s,%s,%s,'GEN','GEN',2026,'2026-01-10','2026-01-10',
                           'GEN',%s) RETURNING id""",
                (acme["tenant_id"], acme["entity_id"], acme["ledger_id"],
                 acme["periods"][1], acme["entity_id"]))
            jid = cur.fetchone()["id"]
            for no, (acct, dirn, amt) in enumerate(
                [("1100", "D", 100_00), ("4000", "C", 90_00)], start=1
            ):
                cur.execute(
                    """INSERT INTO app.journal_line
                        (tenant_id, journal_id, line_no, account_id, direction,
                         txn_currency, txn_amount_minor, func_currency,
                         func_amount_minor, entity_id, period_id, effective_date)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'2026-01-10')""",
                    (acme["tenant_id"], jid, no, acme["accounts"][acct], dirn,
                     ccy, amt, ccy, amt, acme["entity_id"], acme["periods"][1]))
            # deferred constraint fires at COMMIT


def test_deleting_a_draft_line_cannot_leave_it_unbalanced(acme, actor):
    """REGRESSION: the balance trigger must include DELETE.

    Without DELETE in the trigger event list, removing a line from an unposted
    journal in a LATER transaction leaves it permanently unbalanced, silently.
    """
    ccy = acme["currency"]
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute(
            """INSERT INTO app.journal
                 (tenant_id, entity_id, ledger_id, period_id, journal_type,
                  doc_series, fiscal_year, effective_date, document_date,
                  source_module, created_by)
               VALUES (%s,%s,%s,%s,'GEN','DRAFT',2026,'2026-01-11','2026-01-11',
                       'GEN',%s) RETURNING id""",
            (acme["tenant_id"], acme["entity_id"], acme["ledger_id"],
             acme["periods"][1], acme["entity_id"]))
        jid = cur.fetchone()["id"]
        for no, (acct, dirn) in enumerate([("1100", "D"), ("4000", "C")], start=1):
            cur.execute(
                """INSERT INTO app.journal_line
                    (tenant_id, journal_id, line_no, account_id, direction,
                     txn_currency, txn_amount_minor, func_currency,
                     func_amount_minor, entity_id, period_id, effective_date)
                   VALUES (%s,%s,%s,%s,%s,%s,500,%s,500,%s,%s,'2026-01-11')""",
                (acme["tenant_id"], jid, no, acme["accounts"][acct], dirn,
                 ccy, ccy, acme["entity_id"], acme["periods"][1]))

    with pytest.raises(psycopg.errors.CheckViolation, match="unbalanced"):
        with tenant_session(acme["tenant_id"]) as cur:
            cur.execute(
                "DELETE FROM app.journal_line WHERE tenant_id=%s AND journal_id=%s AND line_no=2",
                (acme["tenant_id"], jid))


def test_single_line_journal_rejected_at_post(acme, actor):
    """A zero- or one-line journal never fires a FOR EACH ROW trigger."""
    ccy = acme["currency"]
    d = JournalDraft(
        entity_id=acme["entity_id"], ledger_id=acme["ledger_id"],
        period_id=acme["periods"][1], journal_type="GEN", doc_series="GEN",
        fiscal_year=2026, effective_date=date(2026, 1, 12),
        document_date=date(2026, 1, 12),
        lines=[Line(acme["accounts"]["1100"], "D", Money(0, ccy))],
    )
    with pytest.raises(PostingError, match="at least two lines"):
        post(acme["tenant_id"], d, actor)


def test_posted_journal_is_immutable(acme, actor):
    r = post(acme["tenant_id"], make_draft(acme, amount=42_00), actor)
    with pytest.raises(psycopg.errors.CheckViolation, match="immutable"):
        with tenant_session(acme["tenant_id"]) as cur:
            cur.execute(
                "UPDATE app.journal_line SET txn_amount_minor = 1 "
                "WHERE tenant_id=%s AND journal_id=%s AND line_no=1",
                (acme["tenant_id"], r["journal_id"]))


def test_posted_journal_cannot_be_deleted_even_by_owner(acme, actor):
    r = post(acme["tenant_id"], make_draft(acme, amount=43_00), actor)
    with pytest.raises(psycopg.errors.CheckViolation, match="immutable"):
        with owner_session(tenant_id=acme["tenant_id"]) as cur:
            cur.execute("DELETE FROM app.journal WHERE tenant_id=%s AND id=%s",
                        (acme["tenant_id"], r["journal_id"]))


def test_reversal_is_a_new_journal_not_an_edit(acme, actor):
    orig = post(acme["tenant_id"], make_draft(acme, amount=777_00), actor)
    rev = reverse(acme["tenant_id"], orig["journal_id"], acme["periods"][1],
                  date(2026, 1, 20), actor)

    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT reverses_id FROM app.journal WHERE id=%s", (rev["journal_id"],))
        assert cur.fetchone()["reverses_id"] == orig["journal_id"]

        cur.execute(
            """SELECT sum(CASE direction WHEN 'D' THEN func_amount_minor
                                         ELSE -func_amount_minor END) AS net
                 FROM app.journal_line
                WHERE tenant_id=%s AND journal_id IN (%s, %s)""",
            (acme["tenant_id"], orig["journal_id"], rev["journal_id"]))
        assert cur.fetchone()["net"] == 0

        # The original survives untouched — that is the point of a storno.
        cur.execute("SELECT posted_at FROM app.journal WHERE id=%s", (orig["journal_id"],))
        assert cur.fetchone()["posted_at"] is not None


def test_hash_chain_links_successive_postings(acme, actor):
    a = post(acme["tenant_id"], make_draft(acme, amount=11_00, series="CHAIN"), actor)
    b = post(acme["tenant_id"], make_draft(acme, amount=12_00, series="CHAIN"), actor)
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute("SELECT row_hash FROM app.journal WHERE id=%s", (a["journal_id"],))
        a_hash = cur.fetchone()["row_hash"]
        cur.execute("SELECT prev_hash, row_hash FROM app.journal WHERE id=%s",
                    (b["journal_id"],))
        b_row = cur.fetchone()
    assert bytes(b_row["prev_hash"]) == bytes(a_hash)
    assert bytes(b_row["row_hash"]) != bytes(a_hash)


def test_multicurrency_journal_balances_per_currency(acme, actor):
    """A journal must balance within EACH transaction currency separately.

    There is no universal rate, so cross-currency balancing would make historical
    rate verification impossible. Here: a EUR sale booked in an MYR-functional
    entity, balanced in EUR on the transaction side and in MYR on the functional
    side.
    """
    rate = Decimal("4.85")
    eur = Money(1_000_00, "EUR")
    myr = eur.convert("MYR", rate)
    d = JournalDraft(
        entity_id=acme["entity_id"], ledger_id=acme["ledger_id"],
        period_id=acme["periods"][2], journal_type="SALES", doc_series="FX",
        fiscal_year=2026, effective_date=date(2026, 2, 10),
        document_date=date(2026, 2, 10),
        lines=[
            Line(acme["accounts"]["1100"], "D", eur, func_amount=myr,
                 fx_rate=rate, fx_rate_date=date(2026, 2, 10), fx_rate_type="spot"),
            Line(acme["accounts"]["4000"], "C", eur, func_amount=myr,
                 fx_rate=rate, fx_rate_date=date(2026, 2, 10), fx_rate_type="spot"),
        ],
    )
    r = post(acme["tenant_id"], d, actor)
    assert r["doc_number"].startswith("FX/2026/")
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute(
            """SELECT txn_currency, func_currency, txn_amount_minor, func_amount_minor
                 FROM app.journal_line WHERE journal_id=%s ORDER BY line_no""",
            (r["journal_id"],))
        rows = cur.fetchall()
    assert rows[0]["txn_currency"] == "EUR" and rows[0]["func_currency"] == "MYR"
    assert rows[0]["func_amount_minor"] == 4_850_00


def test_outbox_row_written_in_the_same_transaction(acme, actor):
    """A side effect enqueued in the posting transaction can never be lost."""
    r = post(acme["tenant_id"], make_draft(acme, amount=55_00), actor)
    with tenant_session(acme["tenant_id"]) as cur:
        cur.execute(
            "SELECT topic, payload FROM app.outbox WHERE dedupe_key = %s",
            (f"journal.posted:{r['journal_id']}",))
        row = cur.fetchone()
    assert row["topic"] == "journal.posted"
    assert row["payload"]["doc_number"] == r["doc_number"]


def test_trial_balance_balances_and_matches_the_lines(acme, actor):
    post(acme["tenant_id"], make_draft(acme, period_no=3, amount=1_234_00, day=5), actor)
    post(acme["tenant_id"], make_draft(acme, period_no=3, amount=766_00, day=6), actor)

    rows = trial_balance(acme["tenant_id"], acme["entity_id"], acme["periods"][3])
    dr, cr = trial_balance_totals(rows)
    assert dr.minor == cr.minor == 2_000_00

    # And the cube agrees with the lines it was derived from.
    assert balance_drift(acme["tenant_id"]) == []


def test_idempotency_key_prevents_double_posting(acme, actor):
    d1 = make_draft(acme, amount=99_00, idempotency_key="pay-2026-0001")
    post(acme["tenant_id"], d1, actor)
    d2 = make_draft(acme, amount=99_00, idempotency_key="pay-2026-0001")
    with pytest.raises(psycopg.errors.UniqueViolation):
        post(acme["tenant_id"], d2, actor)
