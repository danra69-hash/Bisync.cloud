"""Phase 0 walking skeleton for a multi-tenant SaaS accounting platform.

Scope is deliberately narrow: everything here is something that cannot be
retrofitted later. See ARCHITECTURE.md §12 for what Phase 1 adds.
"""

__all__ = ["db", "money", "posting", "periods", "reports", "seed", "migrate"]
__version__ = "0.1.0"
