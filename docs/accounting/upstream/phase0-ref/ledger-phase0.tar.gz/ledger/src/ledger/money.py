"""Money as a value object.

An amount is meaningless without its currency, so a bare int never crosses a
function boundary in this codebase. Blueprint §3.8.

Two things this file exists to prevent:

* ``/100`` anywhere. ISO 4217 minor-unit exponents are 0 (JPY, KRW, VND, XAF),
  2 (most), and 3 (KWD, BHD, OMR, JOD, TND, LYD).
* ``round(total / n)`` per part when splitting. That creates or destroys money.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from typing import Sequence

# Minor-unit exponents. In the real system this comes from ref.currency; the
# constant here keeps the value object usable without a database round-trip.
MINOR_UNITS: dict[str, int] = {
    "USD": 2, "EUR": 2, "GBP": 2, "MYR": 2, "SGD": 2,
    "JPY": 0, "KRW": 0, "VND": 0,
    "KWD": 3, "BHD": 3, "OMR": 3, "TND": 3,
}


class CurrencyMismatch(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Money:
    minor: int
    currency: str

    def __post_init__(self) -> None:
        if self.currency not in MINOR_UNITS:
            raise ValueError(f"unknown currency {self.currency!r}")

    # ── construction ────────────────────────────────────────────────────────
    @classmethod
    def parse(cls, amount: str | Decimal, currency: str) -> "Money":
        """Quantise a decimal amount to minor units.

        Rounding mode is set explicitly and deliberately. Python's ``decimal``
        defaults to ROUND_HALF_EVEN (banker's rounding), which surprises
        accountants who expect ROUND_HALF_UP. Make it policy, never a default.
        """
        if currency not in MINOR_UNITS:
            raise ValueError(f"unknown currency {currency!r}")
        exp = MINOR_UNITS[currency]
        q = Decimal(amount).quantize(Decimal(1).scaleb(-exp), rounding=ROUND_HALF_UP)
        return cls(int(q.scaleb(exp)), currency)

    def to_decimal(self) -> Decimal:
        return Decimal(self.minor).scaleb(-MINOR_UNITS[self.currency])

    # ── arithmetic ──────────────────────────────────────────────────────────
    def _same(self, other: "Money") -> None:
        if self.currency != other.currency:
            raise CurrencyMismatch(f"{self.currency} vs {other.currency}")

    def __add__(self, other: "Money") -> "Money":
        self._same(other)
        return Money(self.minor + other.minor, self.currency)

    def __sub__(self, other: "Money") -> "Money":
        self._same(other)
        return Money(self.minor - other.minor, self.currency)

    def __neg__(self) -> "Money":
        return Money(-self.minor, self.currency)

    def __str__(self) -> str:
        return f"{self.to_decimal()} {self.currency}"

    # ── allocation ──────────────────────────────────────────────────────────
    def allocate(self, ratios: Sequence[int]) -> list["Money"]:
        """Split exhaustively across ``ratios``. Sum of parts == self, always.

        This is Fowler's ``allocate``: floor each share, then hand the remaining
        minor units out one at a time in order. The largest-remainder (Hare
        quota) method is equally defensible and gives the SAME TOTAL but a
        DIFFERENT distribution — a customer comparing line allocations will see
        the difference. Pick one, document it, use it everywhere, including
        ASC 606 standalone-selling-price allocation.
        """
        if not ratios or any(r < 0 for r in ratios):
            raise ValueError("ratios must be non-empty and non-negative")
        total = sum(ratios)
        if total == 0:
            raise ValueError("ratios must not sum to zero")

        shares = [self.minor * r // total for r in ratios]
        remainder = self.minor - sum(shares)
        step = 1 if remainder >= 0 else -1
        for i in range(abs(remainder)):
            shares[i % len(shares)] += step
        return [Money(s, self.currency) for s in shares]

    def convert(self, to_currency: str, rate: Decimal) -> "Money":
        """Convert at an explicit rate. Direction is ``self.currency -> to``.

        Inverted-rate bugs are endemic, which is why the rate is never inferred
        and the ledger stores from_ccy/to_ccy/rate_type alongside every value.
        """
        if to_currency not in MINOR_UNITS:
            raise ValueError(f"unknown currency {to_currency!r}")
        exact = self.to_decimal() * Decimal(rate)
        return Money.parse(exact, to_currency)
