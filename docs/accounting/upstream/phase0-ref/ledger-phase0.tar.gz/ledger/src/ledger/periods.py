"""Fiscal periods and the three lock tiers.

    soft lock   admin-exceptable, audit-logged   month-end discipline
    tax lock    nobody, once a return is filed   VAT/GST protection
    hard lock   nobody, IRREVERSIBLY             statutory inalterability

This skeleton implements ``open -> closing -> closed -> hard_closed``; the tax
lock is a localisation-pack concern and lands in Phase 2. Blueprint §3.6.
"""

from __future__ import annotations

import calendar
from datetime import date
from uuid import UUID

from .db import tenant_session


class PeriodError(RuntimeError):
    pass


def create_year(tenant_id: UUID, entity_id: UUID, year: int) -> list[UUID]:
    """Create twelve monthly periods in 'future' status."""
    ids: list[UUID] = []
    with tenant_session(tenant_id) as cur:
        for m in range(1, 13):
            last = calendar.monthrange(year, m)[1]
            cur.execute(
                """INSERT INTO app.fiscal_period
                     (tenant_id, entity_id, year, period_no, start_date, end_date, status)
                   VALUES (%s, %s, %s, %s, %s, %s, 'future')
                   ON CONFLICT (tenant_id, entity_id, year, period_no) DO NOTHING
                   RETURNING id""",
                (tenant_id, entity_id, year, m, date(year, m, 1), date(year, m, last)),
            )
            row = cur.fetchone()
            if row:
                ids.append(row["id"])
    return ids


def set_status(tenant_id: UUID, period_id: UUID, status: str, actor_id: UUID) -> None:
    """Advance a period's status. hard_closed is a one-way door.

    France's PCG caps open fiscal years at two, so a localisation pack will want
    to constrain this further.
    """
    allowed = {
        "future": {"open"},
        "open": {"closing", "open"},
        "closing": {"open", "closed"},
        "closed": {"open", "hard_closed"},   # reopen is possible; see below
        "hard_closed": set(),                # irreversible, by design
    }
    with tenant_session(tenant_id) as cur:
        cur.execute("SELECT status FROM app.fiscal_period WHERE tenant_id=%s AND id=%s",
                    (tenant_id, period_id))
        row = cur.fetchone()
        if row is None:
            raise PeriodError(f"period {period_id} not found")
        current = row["status"]
        if status not in allowed[current]:
            raise PeriodError(f"cannot move period from {current} to {status}")

        cur.execute(
            """UPDATE app.fiscal_period
                  SET status = %s,
                      closed_at = CASE WHEN %s IN ('closed','hard_closed')
                                       THEN now() ELSE NULL END
                WHERE tenant_id = %s AND id = %s""",
            (status, status, tenant_id, period_id))

        # NF203 audit event codes: 50 = period close, 60 = year-end close.
        code = 50 if status in ("closed", "hard_closed") else 15
        cur.execute(
            """INSERT INTO app.audit_event
                 (tenant_id, event_code, event_name, actor_id, object_type,
                  object_id, before, after)
               VALUES (%s, %s, 'period.status_changed', %s, 'fiscal_period', %s,
                       %s::jsonb, %s::jsonb)""",
            (tenant_id, code, actor_id, period_id,
             f'{{"status": "{current}"}}', f'{{"status": "{status}"}}'))

        # Reopening invalidates every downstream snapshot. The cascade is armed
        # on EFFECTIVE DATE, not just on the reopen action: any post into an
        # earlier open period also staleness-invalidates later opening balances.
        if current in ("closed",) and status == "open":
            cur.execute(
                """UPDATE app.period_balance pb
                      SET recompute_after = now()
                     FROM app.fiscal_period p, app.fiscal_period reopened
                    WHERE pb.tenant_id = %s
                      AND reopened.tenant_id = %s AND reopened.id = %s
                      AND p.tenant_id = pb.tenant_id AND p.id = pb.period_id
                      AND p.entity_id = reopened.entity_id
                      AND p.start_date > reopened.start_date""",
                (tenant_id, tenant_id, period_id))


def close_period(tenant_id: UUID, period_id: UUID, actor_id: UUID) -> None:
    """Close a period and roll its closing balances into the next period's opening.

    Note what this does NOT do: physically zero the P&L accounts. Deriving the
    year-end close is the default here, but it is a DEFAULT the localisation
    pack must be able to override — France's PCG requires a real clôture moving
    class 6/7 into account 12, and those entries appear in the FEC. §3.7
    """
    set_status(tenant_id, period_id, "closing", actor_id)
    set_status(tenant_id, period_id, "closed", actor_id)

    with tenant_session(tenant_id) as cur:
        cur.execute(
            """SELECT entity_id, year, period_no FROM app.fiscal_period
                WHERE tenant_id = %s AND id = %s""", (tenant_id, period_id))
        p = cur.fetchone()

        cur.execute(
            """SELECT id FROM app.fiscal_period
                WHERE tenant_id=%s AND entity_id=%s
                  AND (year, period_no) > (%s, %s)
                ORDER BY year, period_no LIMIT 1""",
            (tenant_id, p["entity_id"], p["year"], p["period_no"]))
        nxt = cur.fetchone()
        if nxt is None:
            return  # no successor period created yet

        cur.execute(
            """INSERT INTO app.period_balance AS pb
                 (tenant_id, entity_id, ledger_id, account_id, period_id, txn_currency,
                  opening_txn_dr, opening_txn_cr, opening_func_dr, opening_func_cr)
               SELECT s.tenant_id, s.entity_id, s.ledger_id, s.account_id, %s,
                      s.txn_currency,
                      s.opening_txn_dr  + s.period_txn_dr,
                      s.opening_txn_cr  + s.period_txn_cr,
                      s.opening_func_dr + s.period_func_dr,
                      s.opening_func_cr + s.period_func_cr
                 FROM app.period_balance s
                 JOIN app.account a
                   ON a.tenant_id = s.tenant_id AND a.id = s.account_id
                WHERE s.tenant_id = %s AND s.period_id = %s
                  AND a.type IN ('asset','liability','equity')
               ON CONFLICT (tenant_id, entity_id, ledger_id, account_id,
                            period_id, txn_currency)
               DO UPDATE SET
                  opening_txn_dr  = EXCLUDED.opening_txn_dr,
                  opening_txn_cr  = EXCLUDED.opening_txn_cr,
                  opening_func_dr = EXCLUDED.opening_func_dr,
                  opening_func_cr = EXCLUDED.opening_func_cr""",
            (nxt["id"], tenant_id, period_id))

        cur.execute(
            """UPDATE app.period_balance SET is_frozen = true
                WHERE tenant_id = %s AND period_id = %s""",
            (tenant_id, period_id))
