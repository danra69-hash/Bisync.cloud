"""Reports.

Statutory reports — trial balance, statutory P&L, balance sheet, VAT return —
are served from the TRANSACTIONAL store, never from an eventually-consistent
copy. The read replica and DuckDB layers are for management reporting,
drilldowns and exports. Any number a regulator or auditor sees stays on the
ACID path. Blueprint §6.4.

The trial balance is one indexed scan of the account-level cube. That is the
entire reason ``period_balance`` carries no dimensions — the dimensional cube
exists separately for drilldown and is never the source of a statutory figure.
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID

from .db import tenant_session
from .money import Money


@dataclass(slots=True)
class TrialBalanceRow:
    account_code: str
    account_name: str
    account_type: str
    opening: Money
    debits: Money
    credits: Money
    closing: Money


_TB = """
SELECT a.code, a.name, a.type,
       sum(pb.opening_func_dr - pb.opening_func_cr) AS opening,
       sum(pb.period_func_dr)                        AS dr,
       sum(pb.period_func_cr)                        AS cr,
       sum(pb.opening_func_dr - pb.opening_func_cr
           + pb.period_func_dr - pb.period_func_cr)   AS closing,
       e.func_currency
  FROM app.period_balance pb
  JOIN app.account a ON a.tenant_id = pb.tenant_id AND a.id = pb.account_id
  JOIN app.entity  e ON e.tenant_id = pb.tenant_id AND e.id = pb.entity_id
 WHERE pb.tenant_id = %(tenant)s
   AND pb.entity_id = %(entity)s
   AND pb.period_id = %(period)s
 GROUP BY a.code, a.name, a.type, e.func_currency
 HAVING sum(pb.opening_func_dr - pb.opening_func_cr
            + pb.period_func_dr - pb.period_func_cr) <> 0
     OR sum(pb.period_func_dr) <> 0 OR sum(pb.period_func_cr) <> 0
 ORDER BY a.code
"""


def trial_balance(tenant_id: UUID, entity_id: UUID, period_id: UUID) -> list[TrialBalanceRow]:
    with tenant_session(tenant_id) as cur:
        cur.execute(_TB, {"tenant": tenant_id, "entity": entity_id, "period": period_id})
        rows = cur.fetchall()

    out = []
    for r in rows:
        ccy = r["func_currency"]
        out.append(TrialBalanceRow(
            account_code=r["code"], account_name=r["name"], account_type=r["type"],
            opening=Money(int(r["opening"]), ccy),
            debits=Money(int(r["dr"]), ccy),
            credits=Money(int(r["cr"]), ccy),
            closing=Money(int(r["closing"]), ccy),
        ))
    return out


def trial_balance_totals(rows: list[TrialBalanceRow]) -> tuple[Money, Money]:
    """Debits and credits for the period. These must be equal — that is the point."""
    if not rows:
        return Money(0, "USD"), Money(0, "USD")
    ccy = rows[0].debits.currency
    return (Money(sum(r.debits.minor for r in rows), ccy),
            Money(sum(r.credits.minor for r in rows), ccy))


def balance_drift(tenant_id: UUID) -> list[dict]:
    """Cube vs lines. Empty means clean; anything else is a page.

    Run nightly. A balance cache that can silently drift in a ledger is a defect
    generator — treat this as mandatory, not optional.
    """
    with tenant_session(tenant_id) as cur:
        cur.execute("SELECT * FROM app.detect_balance_drift(%s)", (tenant_id,))
        return cur.fetchall()
