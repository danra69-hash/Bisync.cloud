"""Minimal forward-only migration runner.

Deliberately ~60 lines. In Phase 1 the non-ledger tables move under Django's
migration framework — that maturity is the main reason the blueprint picks
Django — but the ledger core stays as reviewed SQL, because composite primary
keys, partitioning and constraint triggers all sit outside what Django's
autodetector can express.
"""

from __future__ import annotations

import hashlib
import pathlib
import sys

from .db import admin_session

MIGRATIONS = pathlib.Path(__file__).resolve().parents[2] / "db" / "migrations"

_BOOTSTRAP = """
CREATE TABLE IF NOT EXISTS public.schema_migration (
  filename   text PRIMARY KEY,
  sha256     text NOT NULL,
  applied_at timestamptz NOT NULL DEFAULT now()
)
"""


def apply_all(verbose: bool = True) -> list[str]:
    applied: list[str] = []
    with admin_session() as cur:
        cur.execute(_BOOTSTRAP)
        cur.execute("SELECT filename, sha256 FROM public.schema_migration")
        seen = {r["filename"]: r["sha256"] for r in cur.fetchall()}

    for path in sorted(MIGRATIONS.glob("*.sql")):
        body = path.read_text()
        digest = hashlib.sha256(body.encode()).hexdigest()
        if path.name in seen:
            if seen[path.name] != digest:
                raise RuntimeError(
                    f"{path.name} has changed since it was applied. Migrations are "
                    f"forward-only; add a new file instead."
                )
            continue
        with admin_session() as cur:
            cur.execute(body)
            cur.execute(
                "INSERT INTO public.schema_migration (filename, sha256) VALUES (%s, %s)",
                (path.name, digest))
        applied.append(path.name)
        if verbose:
            print(f"  applied {path.name}")
    return applied


if __name__ == "__main__":
    names = apply_all()
    print(f"{len(names)} migration(s) applied" if names else "already up to date")
    sys.exit(0)
