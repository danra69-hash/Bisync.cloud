"""The posting engine.

Only this module writes journal lines. Everything upstream (AR, AP, banking, the
SLA rule engine) produces a *balanced draft* and hands it here; the ledger core
validates and seals it. Enforce that boundary with a code-owner rule, not a
convention. Blueprint §1.2.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Sequence
from uuid import UUID

from .db import tenant_session
from .money import Money


class PostingError(RuntimeError):
    pass


@dataclass(slots=True)
class Line:
    account_id: UUID
    direction: str                      # 'D' | 'C'
    amount: Money                       # transaction currency
    func_amount: Money | None = None    # functional currency; defaults to amount
    fx_rate: Decimal | None = None
    fx_rate_date: date | None = None
    fx_rate_type: str | None = None
    cost_centre_id: UUID | None = None
    project_id: UUID | None = None
    department_id: UUID | None = None
    partner_entity_id: UUID | None = None
    dimensions: dict = field(default_factory=dict)
    cashflow_category: str | None = None
    narration: str | None = None

    def __post_init__(self) -> None:
        if self.direction not in ("D", "C"):
            raise ValueError("direction must be 'D' or 'C'")
        if self.amount.minor < 0:
            raise ValueError("amounts are non-negative; use direction to signal sign")
        if self.func_amount is None:
            self.func_amount = self.amount
        elif self.func_amount.currency != self.amount.currency and self.fx_rate is None:
            raise ValueError("a cross-currency line needs an explicit fx_rate")


@dataclass(slots=True)
class JournalDraft:
    entity_id: UUID
    ledger_id: UUID
    period_id: UUID
    journal_type: str
    doc_series: str
    fiscal_year: int
    effective_date: date
    document_date: date
    lines: Sequence[Line]
    source_module: str = "GEN"
    source_doc_id: UUID | None = None
    reverses_id: UUID | None = None
    idempotency_key: str | None = None
    narration: str | None = None

    def check_balanced(self) -> None:
        """Fail fast in the application before touching the database.

        The database enforces this too, via a deferred constraint trigger. Both
        layers are deliberate: the app gives a good error message, the database
        makes the invariant true even for a bad migration script.
        """
        by_ccy: dict[str, int] = {}
        func_total = 0
        for ln in self.lines:
            sign = 1 if ln.direction == "D" else -1
            by_ccy[ln.amount.currency] = by_ccy.get(ln.amount.currency, 0) + sign * ln.amount.minor
            func_total += sign * ln.func_amount.minor
        bad = {c: d for c, d in by_ccy.items() if d != 0}
        if bad:
            raise PostingError(f"unbalanced in transaction currency: {bad}")
        if func_total != 0:
            raise PostingError(f"unbalanced in functional currency: {func_total}")


_INSERT_JOURNAL = """
INSERT INTO app.journal
  (tenant_id, entity_id, ledger_id, period_id, journal_type, doc_series,
   fiscal_year, effective_date, document_date, source_module, source_doc_id,
   reverses_id, idempotency_key, narration, created_by)
VALUES (%(tenant)s, %(entity)s, %(ledger)s, %(period)s, %(jtype)s, %(series)s,
        %(fy)s, %(eff)s, %(doc)s, %(module)s, %(source)s,
        %(reverses)s, %(idem)s, %(narr)s, %(actor)s)
RETURNING id
"""

_INSERT_LINE = """
INSERT INTO app.journal_line
  (tenant_id, journal_id, line_no, account_id, direction,
   txn_currency, txn_amount_minor, func_currency, func_amount_minor,
   fx_rate, fx_rate_date, fx_rate_type,
   entity_id, period_id, cost_centre_id, project_id, department_id,
   partner_entity_id, dimensions, cashflow_category, effective_date, narration)
VALUES
  (%(tenant)s, %(journal)s, %(no)s, %(account)s, %(dir)s,
   %(txn_ccy)s, %(txn_amt)s, %(func_ccy)s, %(func_amt)s,
   %(rate)s, %(rate_date)s, %(rate_type)s,
   %(entity)s, %(period)s, %(cc)s, %(project)s, %(dept)s,
   %(partner)s, %(dims)s, %(cf)s, %(eff)s, %(narr)s)
"""


def post(tenant_id: UUID, draft: JournalDraft, actor_id: UUID) -> dict:
    """Create and seal a journal in one transaction.

    Ordering matters and is not arbitrary:

    1. validate in the application (good errors)
    2. insert the draft and its lines
    3. ``app.post_journal`` takes the document number LAST, after all
       validation, because the counter row lock is held until COMMIT and lock
       hold time is the whole game
    4. the outbox row is written in the SAME transaction, so a side effect can
       never be lost after a successful commit

    Never call an external service between 3 and COMMIT.
    """
    draft.check_balanced()
    if len(draft.lines) < 2:
        raise PostingError("a posting needs at least two lines")

    with tenant_session(tenant_id) as cur:
        cur.execute(_INSERT_JOURNAL, {
            "tenant": tenant_id, "entity": draft.entity_id, "ledger": draft.ledger_id,
            "period": draft.period_id, "jtype": draft.journal_type,
            "series": draft.doc_series, "fy": draft.fiscal_year,
            "eff": draft.effective_date, "doc": draft.document_date,
            "module": draft.source_module, "source": draft.source_doc_id,
            "reverses": draft.reverses_id, "idem": draft.idempotency_key,
            "narr": draft.narration, "actor": actor_id,
        })
        journal_id = cur.fetchone()["id"]

        for i, ln in enumerate(draft.lines, start=1):
            cur.execute(_INSERT_LINE, {
                "tenant": tenant_id, "journal": journal_id, "no": i,
                "account": ln.account_id, "dir": ln.direction,
                "txn_ccy": ln.amount.currency, "txn_amt": ln.amount.minor,
                "func_ccy": ln.func_amount.currency, "func_amt": ln.func_amount.minor,
                "rate": ln.fx_rate, "rate_date": ln.fx_rate_date,
                "rate_type": ln.fx_rate_type,
                "entity": draft.entity_id, "period": draft.period_id,
                "cc": ln.cost_centre_id, "project": ln.project_id,
                "dept": ln.department_id, "partner": ln.partner_entity_id,
                "dims": json.dumps(ln.dimensions), "cf": ln.cashflow_category,
                "eff": draft.effective_date, "narr": ln.narration,
            })

        cur.execute("SELECT app.post_journal(%s, %s) AS doc_number",
                    (journal_id, actor_id))
        doc_number = cur.fetchone()["doc_number"]

        # Transactional outbox: enqueued here, published by a relay. This is
        # what makes "journal committed but task lost" impossible.
        cur.execute(
            """INSERT INTO app.outbox (tenant_id, topic, payload, dedupe_key)
               VALUES (%s, 'journal.posted', %s, %s)""",
            (tenant_id,
             json.dumps({"journal_id": str(journal_id), "doc_number": doc_number}),
             f"journal.posted:{journal_id}"),
        )

    return {"journal_id": journal_id, "doc_number": doc_number}


def reverse(tenant_id: UUID, journal_id: UUID, period_id: UUID,
            effective_date: date, actor_id: UUID) -> dict:
    """Storno: post an equal-and-opposite journal linked via ``reverses_id``.

    Corrections are never edits. If the original period is closed, the reversal
    lands in an open one — which is why the caller supplies the period rather
    than the engine inferring it.
    """
    with tenant_session(tenant_id) as cur:
        cur.execute(
            """SELECT j.entity_id, j.ledger_id, j.doc_series, j.fiscal_year,
                      j.journal_type, j.posted_at
                 FROM app.journal j WHERE j.tenant_id = %s AND j.id = %s""",
            (tenant_id, journal_id))
        orig = cur.fetchone()
        if orig is None:
            raise PostingError(f"journal {journal_id} not found in this tenant")
        if orig["posted_at"] is None:
            raise PostingError("cannot reverse a draft; discard it instead")

        cur.execute(
            """SELECT line_no, account_id, direction, txn_currency, txn_amount_minor,
                      func_currency, func_amount_minor, fx_rate, fx_rate_date,
                      fx_rate_type, cost_centre_id, project_id, department_id,
                      partner_entity_id, dimensions, cashflow_category
                 FROM app.journal_line
                WHERE tenant_id = %s AND journal_id = %s ORDER BY line_no""",
            (tenant_id, journal_id))
        rows = cur.fetchall()

    lines = [
        Line(
            account_id=r["account_id"],
            direction="C" if r["direction"] == "D" else "D",   # flipped
            amount=Money(r["txn_amount_minor"], r["txn_currency"]),
            func_amount=Money(r["func_amount_minor"], r["func_currency"]),
            fx_rate=r["fx_rate"], fx_rate_date=r["fx_rate_date"],
            fx_rate_type=r["fx_rate_type"],
            cost_centre_id=r["cost_centre_id"], project_id=r["project_id"],
            department_id=r["department_id"], partner_entity_id=r["partner_entity_id"],
            dimensions=r["dimensions"] or {}, cashflow_category=r["cashflow_category"],
            narration=f"Reversal of {journal_id}",
        )
        for r in rows
    ]

    draft = JournalDraft(
        entity_id=orig["entity_id"], ledger_id=orig["ledger_id"], period_id=period_id,
        journal_type=orig["journal_type"], doc_series=orig["doc_series"],
        fiscal_year=orig["fiscal_year"], effective_date=effective_date,
        document_date=effective_date, lines=lines, source_module="GEN",
        reverses_id=journal_id, narration=f"Reversal of {journal_id}",
    )
    return post(tenant_id, draft, actor_id)
