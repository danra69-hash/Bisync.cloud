"""Connection handling and the tenant session wrapper.

This module is the single most important security control in the codebase.
Nothing outside it may open a database session.

The rules it enforces, from blueprint §2.5:

1. Tenant context is set with ``set_config(..., is_local => true)`` INSIDE an
   explicit transaction. Never a plain ``SET``, which persists for the life of
   the *server* connection and is handed to the next client at COMMIT under
   PgBouncer transaction pooling — tenant A's context becomes tenant B's.

2. ``set_config()`` rather than ``SET LOCAL`` because ``SET LOCAL`` is a utility
   statement and cannot be parameterised, forcing string interpolation of the
   tenant id. ``set_config()`` takes a bind parameter.

3. Client-side prepared-statement caching is disabled. This is required twice
   over: once for PgBouncer transaction pooling, and once to defeat cross-tenant
   cached-plan reuse (§2.6).

4. RLS fails closed *silently* — zero rows. Correct for security, terrible for
   debugging. So the application layer fails LOUDLY: using the engine without a
   tenant context raises rather than quietly returning nothing.

Background jobs, workers, management commands and data migrations must all go
through ``tenant_session`` too. That is where leaks live; everyone remembers to
fix the request path.
"""

from __future__ import annotations

import contextlib
import os
from typing import Iterator
from uuid import UUID

import psycopg
from psycopg.rows import dict_row


class NoTenantContext(RuntimeError):
    """Raised when tenant-scoped work is attempted without a tenant."""


def _dsn(role: str) -> str:
    env = {
        "app_rw": "LEDGER_DSN_RW",
        "app_reports": "LEDGER_DSN_REPORTS",
        "admin": "LEDGER_DSN_ADMIN",
    }[role]
    dsn = os.environ.get(env)
    if not dsn:
        raise RuntimeError(f"{env} is not set; copy .env.example and source it")
    return dsn


def _connect(role: str) -> psycopg.Connection:
    conn = psycopg.connect(
        _dsn(role),
        row_factory=dict_row,
        autocommit=False,
        # See rule 3 above. psycopg3 prepares after prepare_threshold executions;
        # None disables it entirely.
        prepare_threshold=None,
    )
    return conn


@contextlib.contextmanager
def tenant_session(tenant_id: UUID | str, role: str = "app_rw") -> Iterator[psycopg.Cursor]:
    """The ONLY supported way to touch tenant data.

    One logical request == one transaction. The GUC is transaction-local, so it
    expires exactly when the connection returns to the pooler.
    """
    if tenant_id is None:
        raise NoTenantContext("tenant_session requires a tenant id")

    conn = _connect(role)
    try:
        with conn:  # BEGIN ... COMMIT / ROLLBACK
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT set_config('app.tenant_id', %s, true)", (str(tenant_id),)
                )
                yield cur
    finally:
        conn.close()


@contextlib.contextmanager
def admin_session() -> Iterator[psycopg.Cursor]:
    """Control-plane and migration work. Sets no tenant context by design.

    Any attempt to read app.* through this without a tenant returns zero rows,
    which is why the CI gate checks role reachability rather than trusting it.
    """
    conn = _connect("admin")
    try:
        with conn:
            with conn.cursor() as cur:
                yield cur
    finally:
        conn.close()


@contextlib.contextmanager
def owner_session(tenant_id: UUID | str | None = None) -> Iterator[psycopg.Cursor]:
    """Maintenance path: SET ROLE app_owner, optionally scoped to a tenant.

    The RESTRICTIVE floor still binds app_owner, so even maintenance is
    tenant-scoped unless a tenant is supplied — it is not a bypass.
    """
    conn = _connect("admin")
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute("SET ROLE app_owner")
                if tenant_id is not None:
                    cur.execute(
                        "SELECT set_config('app.tenant_id', %s, true)", (str(tenant_id),)
                    )
                yield cur
    finally:
        conn.close()
