"""Demo tenant provisioning.

Two tenants with structurally identical data. That is not laziness: the
cross-tenant fuzzer needs two tenants whose fixtures have the same *shape* and
different *values*, so that a leak shows up as recognisable foreign data rather
than as a plausible-looking row.
"""

from __future__ import annotations

from datetime import date
from uuid import UUID

from .db import admin_session, tenant_session
from .periods import create_year, set_status

# A deliberately small, IFRS-shaped internal chart. Statutory charts (France's
# PCG, Germany's SKR) are localisation-pack concerns that MAP onto this one —
# never a single global chart with country flags. §5.2
CHART = [
    ("1000", "Cash at bank",        "asset",     "D"),
    ("1100", "Accounts receivable", "asset",     "D"),
    ("1200", "Inventory",           "asset",     "D"),
    ("2000", "Accounts payable",    "liability", "C"),
    ("2100", "VAT payable",         "liability", "C"),
    ("3000", "Share capital",       "equity",    "C"),
    ("3900", "Retained earnings",   "equity",    "C"),
    ("4000", "Revenue",             "income",    "C"),
    ("5000", "Cost of goods sold",  "expense",   "D"),
    ("6000", "Operating expenses",  "expense",   "D"),
    # Every ledger needs somewhere for the plug to go. A posting engine that
    # cannot balance posts here AND raises an alert — it never silently adjusts
    # a real account. §3.8
    ("7100", "FX gain/loss — realised",   "expense", "D"),
    ("7110", "FX gain/loss — unrealised", "expense", "D"),
    ("7200", "Rounding difference",       "expense", "D"),
    ("9900", "Suspense / clearing",       "asset",   "D"),
]


def provision_tenant(slug: str, name: str, entity_code: str,
                     func_currency: str, country: str, year: int) -> dict:
    """Create a tenant, its routing row, one entity, a ledger, a chart and a year."""
    with admin_session() as cur:
        cur.execute(
            "INSERT INTO control.tenant (slug, name) VALUES (%s, %s) RETURNING id",
            (slug, name))
        tenant_id: UUID = cur.fetchone()["id"]
        # Standard tier today; the routing row is what makes promotion to a
        # dedicated database or region a config change rather than a rewrite.
        cur.execute(
            """INSERT INTO control.tenant_routing
                 (tenant_id, cluster_key, region, tier, status)
               VALUES (%s, 'primary', 'eu-central-1', 'standard', 'active')""",
            (tenant_id,))

    with tenant_session(tenant_id) as cur:
        cur.execute(
            """INSERT INTO app.entity (tenant_id, code, name, func_currency, country)
               VALUES (%s, %s, %s, %s, %s) RETURNING id""",
            (tenant_id, entity_code, name, func_currency, country))
        entity_id = cur.fetchone()["id"]

        cur.execute(
            """INSERT INTO app.ledger (tenant_id, entity_id, kind, name)
               VALUES (%s, %s, 'primary', 'Primary ledger') RETURNING id""",
            (tenant_id, entity_id))
        ledger_id = cur.fetchone()["id"]

        accounts = {}
        for code, acct_name, type_, normal in CHART:
            cur.execute(
                """INSERT INTO app.account
                     (tenant_id, code, name, type, normal_balance)
                   VALUES (%s, %s, %s, %s, %s) RETURNING id""",
                (tenant_id, code, acct_name, type_, normal))
            accounts[code] = cur.fetchone()["id"]

    create_year(tenant_id, entity_id, year)

    with tenant_session(tenant_id) as cur:
        cur.execute(
            """SELECT id, period_no FROM app.fiscal_period
                WHERE tenant_id=%s AND entity_id=%s AND year=%s
                ORDER BY period_no""", (tenant_id, entity_id, year))
        periods = {r["period_no"]: r["id"] for r in cur.fetchall()}

    # Open the first three months so tests have somewhere to post.
    for m in (1, 2, 3):
        set_status(tenant_id, periods[m], "open", actor_id=entity_id)

    return {
        "tenant_id": tenant_id, "entity_id": entity_id, "ledger_id": ledger_id,
        "accounts": accounts, "periods": periods, "currency": func_currency,
        "year": year,
    }


def seed_demo(year: int = 2026) -> dict:
    return {
        "acme": provision_tenant("acme", "Acme Trading Sdn Bhd", "ACME", "MYR", "MY", year),
        "globex": provision_tenant("globex", "Globex SARL", "GLBX", "EUR", "FR", year),
    }


if __name__ == "__main__":
    out = seed_demo()
    for k, v in out.items():
        print(f"{k}: tenant={v['tenant_id']} entity={v['entity_id']} ccy={v['currency']}")
