-- CI GATE 1 — no table ships without RLS.
--
-- Any row returned is a build failure.
--
-- Note relkind IN ('r','p'): partitioned tables AND their partitions are both
-- checked, because a query issued directly against a partition uses that
-- partition's own RLS state.

\set ON_ERROR_STOP on

WITH tenant_tables AS (
  SELECT c.oid, n.nspname AS schema_name, c.relname AS table_name,
         c.relrowsecurity, c.relforcerowsecurity,
         EXISTS (SELECT 1 FROM pg_inherits i WHERE i.inhrelid = c.oid) AS is_partition
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
   WHERE n.nspname = 'app'
     AND c.relkind IN ('r','p')
     AND EXISTS (SELECT 1 FROM pg_attribute a
                  WHERE a.attrelid = c.oid AND a.attname = 'tenant_id'
                    AND NOT a.attisdropped)
)
SELECT schema_name, table_name, is_partition,
       relrowsecurity      AS rls_enabled,
       relforcerowsecurity AS rls_forced,
       (SELECT count(*) FROM pg_policy p WHERE p.polrelid = t.oid) AS n_policies,
       (SELECT count(*) FROM pg_policy p
         WHERE p.polrelid = t.oid AND NOT p.polpermissive)         AS n_restrictive
  FROM tenant_tables t
 -- Enabled + forced is required everywhere, partitions included: a query issued
 -- directly against a partition uses that partition's own RLS state.
 WHERE NOT relrowsecurity
    OR NOT relforcerowsecurity
    -- On a base table, a RESTRICTIVE floor is required — not merely "some
    -- policy". Without it, any future permissive USING (true) policy silently
    -- widens access. On a partition, zero policies is correct: enabled + forced
    -- with no policy is default-deny, and access goes through the parent.
    OR (NOT is_partition
        AND (SELECT count(*) FROM pg_policy p
              WHERE p.polrelid = t.oid AND NOT p.polpermissive) = 0);
