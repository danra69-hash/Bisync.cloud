-- CI GATE 2 — bypass audit and index discipline.
--
-- Any row returned is a build failure.

\set ON_ERROR_STOP on

-- 2a. No runtime role may bypass RLS. Never run application traffic as the RDS
--     master user: reports of it bypassing RLS are usually explained by object
--     ownership without FORCE, but verify empirically on YOUR instance.
SELECT 'bypass_role' AS finding, rolname, rolsuper, rolbypassrls, rolcreaterole
  FROM pg_roles
 WHERE rolname IN ('app_rw','app_reports')
   AND (rolsuper OR rolbypassrls OR rolcreaterole);

-- 2b. No non-builtin function may be marked LEAKPROOF. A leakproof qual is safe
--     to push BELOW the RLS barrier — which is exactly why an incorrectly
--     marked one is a leak primitive.
SELECT 'leakproof_function' AS finding, n.nspname, p.proname
  FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
 WHERE p.proleakproof AND n.nspname NOT IN ('pg_catalog','information_schema');

-- 2c. Every view over tenant data must be security_invoker. A view otherwise
--     executes with its OWNER's privileges and policies.
SELECT 'non_invoker_view' AS finding, n.nspname, c.relname
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE c.relkind = 'v' AND n.nspname = 'app'
   AND coalesce(array_to_string(c.reloptions, ','), '') NOT LIKE '%security_invoker=%';

-- 2d. Materialized views escape RLS entirely — data is physically copied. Any
--     matview over tenant data is a cross-tenant artefact by construction.
SELECT 'materialized_view' AS finding, n.nspname, c.relname
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE c.relkind = 'm' AND n.nspname = 'app';

-- 2e. Every index on a tenant table must lead with tenant_id. RLS makes missing
--     or badly-ordered indexes far more likely, because the predicate is
--     invisible in application code.
SELECT 'index_not_tenant_first' AS finding, n.nspname, c.relname AS table_name, i.relname AS index_name
  FROM pg_index x
  JOIN pg_class c ON c.oid = x.indrelid
  JOIN pg_class i ON i.oid = x.indexrelid
  JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'app'
   AND EXISTS (SELECT 1 FROM pg_attribute a
                WHERE a.attrelid = c.oid AND a.attname='tenant_id' AND NOT a.attisdropped)
   AND (SELECT a.attname FROM pg_attribute a
         WHERE a.attrelid = c.oid AND a.attnum = x.indkey[0]) IS DISTINCT FROM 'tenant_id';

-- 2f. TRUNCATE is not subject to RLS at all. It must never be granted.
SELECT 'truncate_granted' AS finding, table_schema, table_name, grantee
  FROM information_schema.role_table_grants
 WHERE privilege_type = 'TRUNCATE'
   AND grantee IN ('app_rw','app_reports')
   AND table_schema = 'app';
