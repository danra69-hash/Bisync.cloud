-- 0002 — control plane.
--
-- In production this lives in a SEPARATE database. It is here in the same
-- cluster only so the skeleton runs with one connection string. It holds no
-- tenant financial data and therefore carries no RLS.
--
-- tenant_routing is the whole point of this migration. It is ~50 lines and it
-- is the difference between promoting a whale to its own database and
-- rewriting every connection site in the codebase. Build it while you still
-- have one cluster. Blueprint §2.2.

SET ROLE app_owner;

CREATE TABLE control.tenant (
  id          uuid PRIMARY KEY DEFAULT app.uuid7(),
  slug        text NOT NULL UNIQUE,
  name        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE control.tenant_routing (
  tenant_id   uuid PRIMARY KEY REFERENCES control.tenant(id),
  cluster_key text NOT NULL,                    -- resolves to a DSN in config
  region      text NOT NULL,
  tier        text NOT NULL CHECK (tier   IN ('standard','dedicated','regional')),
  status      text NOT NULL CHECK (status IN ('active','migrating','frozen','suspended')),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- 'frozen' is the cutover primitive: during promotion, that tenant's writes 503
-- for the ~30s it takes to verify replication lag and flip the row.
CREATE INDEX ON control.tenant_routing (cluster_key) WHERE status = 'active';

GRANT SELECT ON ALL TABLES IN SCHEMA control TO app_rw, app_reports;
GRANT INSERT, UPDATE ON control.tenant, control.tenant_routing TO app_rw;

RESET ROLE;
