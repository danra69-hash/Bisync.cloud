-- 0006 — Row-Level Security.
--
-- RLS is the right SECOND layer, not the only one. It turns an application bug
-- into zero rows instead of a breach. Because it fails SILENTLY, the
-- application layer must fail LOUDLY — see src/ledger/db.py.
--
-- THE TRAP, stated explicitly because it is silent:
--   RESTRICTIVE policies only ever SUBTRACT. The final predicate is
--       (all RESTRICTIVE AND-ed) AND (all PERMISSIVE OR-ed)
--   so a role with no permissive policy of its own matches NOTHING. Ship only
--   the app_rw policy and app_reports returns zero rows on every table, every
--   report is empty, and app_owner data migrations silently no-op instead of
--   failing. In a ledger, a migration that reports success and changes nothing
--   is the worst available outcome.
--
-- The CI gate in db/ci/ asserts reachability PER ROLE, not merely that a policy
-- exists — because "≥1 policy exists" passes the broken configuration.

SET ROLE app_owner;

CREATE OR REPLACE FUNCTION app.apply_tenant_rls(p_schema text, p_table text)
RETURNS void
LANGUAGE plpgsql AS $$
DECLARE r record;
BEGIN
  EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY',  p_schema, p_table);
  -- Without FORCE, the table OWNER bypasses every policy.
  EXECUTE format('ALTER TABLE %I.%I FORCE  ROW LEVEL SECURITY',  p_schema, p_table);

  -- The hard floor. RESTRICTIVE survives a future engineer adding a permissive
  -- USING (true) policy — which a plain permissive-only design would not.
  EXECUTE format($f$
    CREATE POLICY %I ON %I.%I AS RESTRICTIVE TO PUBLIC
      USING      (tenant_id = app.current_tenant())
      WITH CHECK (tenant_id = app.current_tenant())
  $f$, p_table || '_tenant_floor', p_schema, p_table);

  -- One permissive policy PER ROLE that needs access.
  EXECUTE format($f$
    CREATE POLICY %I ON %I.%I FOR ALL TO app_rw USING (true) WITH CHECK (true)
  $f$, p_table || '_rw', p_schema, p_table);

  EXECUTE format($f$
    CREATE POLICY %I ON %I.%I FOR SELECT TO app_reports USING (true)
  $f$, p_table || '_ro', p_schema, p_table);

  -- The migration/maintenance path. app_owner is NOLOGIN and reachable only via
  -- SET ROLE from an admin connection; the restrictive floor still binds it, so
  -- maintenance is tenant-scoped too rather than unscoped.
  EXECUTE format($f$
    CREATE POLICY %I ON %I.%I FOR ALL TO app_owner USING (true) WITH CHECK (true)
  $f$, p_table || '_owner', p_schema, p_table);

  -- A query issued DIRECTLY against a partition uses that partition's own RLS
  -- state — policies on the parent are not inherited for that path.
  FOR r IN
    SELECT n.nspname AS s, c.relname AS t
      FROM pg_inherits i
      JOIN pg_class c     ON c.oid = i.inhrelid
      JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE i.inhparent = format('%I.%I', p_schema, p_table)::regclass
  LOOP
    EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', r.s, r.t);
    EXECUTE format('ALTER TABLE %I.%I FORCE  ROW LEVEL SECURITY', r.s, r.t);
  END LOOP;
END $$;

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT c.relname
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = 'app'
       AND c.relkind IN ('r','p')
       AND NOT EXISTS (SELECT 1 FROM pg_inherits i WHERE i.inhrelid = c.oid)  -- skip partitions
       AND EXISTS (SELECT 1 FROM pg_attribute a
                    WHERE a.attrelid = c.oid AND a.attname = 'tenant_id'
                      AND NOT a.attisdropped)
  LOOP
    PERFORM app.apply_tenant_rls('app', r.relname);
  END LOOP;
END $$;

-- Grants. Note TRUNCATE is NEVER granted: it is not subject to RLS at all.
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA app TO app_rw;
GRANT SELECT                          ON ALL TABLES IN SCHEMA app TO app_reports;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA app TO app_rw;

RESET ROLE;
