-- 0001 — extensions, schemas, roles.
--
-- Roles are cluster-wide, so this migration is idempotent and safe to re-run.
-- The three-role split is the load-bearing part of the isolation design:
--
--   app_owner    owns every table. Runs migrations. NEVER used at runtime.
--   app_rw       runtime read/write. No BYPASSRLS, not an owner, no CREATEROLE.
--   app_reports  read-only, replica-bound. Needs its OWN permissive policy or
--                it sees zero rows on every table (see 0006).
--
-- Blueprint §2.3.

CREATE EXTENSION IF NOT EXISTS pgcrypto;    -- gen_random_uuid(), digest()
CREATE EXTENSION IF NOT EXISTS btree_gin;   -- lets GIN indexes lead with tenant_id

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_owner') THEN
    CREATE ROLE app_owner NOLOGIN NOSUPERUSER NOCREATEROLE NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_rw') THEN
    CREATE ROLE app_rw LOGIN PASSWORD 'app_rw' NOSUPERUSER NOCREATEROLE NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_reports') THEN
    CREATE ROLE app_reports LOGIN PASSWORD 'app_reports' NOSUPERUSER NOCREATEROLE NOBYPASSRLS;
  END IF;
END $$;

-- Schemas are owned by app_owner, which is the only role that may create
-- objects. app_rw gets USAGE, never CREATE: a runtime role that can create a
-- table can create one without an RLS policy.
CREATE SCHEMA IF NOT EXISTS control AUTHORIZATION app_owner;  -- no tenant financial data
CREATE SCHEMA IF NOT EXISTS ref     AUTHORIZATION app_owner;  -- global, no tenant_id
CREATE SCHEMA IF NOT EXISTS app     AUTHORIZATION app_owner;  -- tenant data, RLS-protected

-- Timeouts are not optional in a shared cluster: one tenant's runaway report
-- holding a transaction open blocks vacuum for everyone. §2.6
ALTER ROLE app_rw      SET statement_timeout = '15s';
ALTER ROLE app_rw      SET idle_in_transaction_session_timeout = '30s';
ALTER ROLE app_reports SET statement_timeout = '10min';

-- Skewed tenant sizes + cached plans = nondeterministic latency. Role-scoped,
-- never global. Note this does NOT rescue parameterless prepared statements,
-- which is why the driver also disables client-side statement caching. §2.6
ALTER ROLE app_rw SET plan_cache_mode = 'force_custom_plan';

-- CVE-2018-1058: an unqualified operator in a SECURITY DEFINER function can be
-- shadowed by an object a caller created in public.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

GRANT USAGE ON SCHEMA control, ref, app TO app_rw, app_reports;

-- ─────────────────────────────────────────────────────────────────────────────
-- uuid7(): k-sortable ids — 48-bit ms timestamp in the high bits gives B-tree
-- insert locality, random low bits keep them unguessable. PostgreSQL 18 ships
-- uuidv7() natively; this shim exists so the skeleton runs on 16/17. On 18,
-- replace the body with `SELECT uuidv7()`.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.uuid7() RETURNS uuid
LANGUAGE plpgsql VOLATILE AS $$
DECLARE
  v_ts_ms bigint := (extract(epoch FROM clock_timestamp()) * 1000)::bigint;
  v_bytes bytea  := gen_random_bytes(16);
BEGIN
  -- 48 bits of timestamp
  v_bytes := set_byte(v_bytes, 0, ((v_ts_ms >> 40) & 255)::int);
  v_bytes := set_byte(v_bytes, 1, ((v_ts_ms >> 32) & 255)::int);
  v_bytes := set_byte(v_bytes, 2, ((v_ts_ms >> 24) & 255)::int);
  v_bytes := set_byte(v_bytes, 3, ((v_ts_ms >> 16) & 255)::int);
  v_bytes := set_byte(v_bytes, 4, ((v_ts_ms >>  8) & 255)::int);
  v_bytes := set_byte(v_bytes, 5, ( v_ts_ms        & 255)::int);
  -- version 7, variant 10xx
  v_bytes := set_byte(v_bytes, 6, ((get_byte(v_bytes, 6) & 15) | 112));
  v_bytes := set_byte(v_bytes, 8, ((get_byte(v_bytes, 8) & 63) | 128));
  RETURN encode(v_bytes, 'hex')::uuid;
END $$;

-- The tenant context accessor. NULLIF is load-bearing, not cosmetic:
--
--   fresh backend, GUC never set     -> current_setting() returns NULL
--   recycled backend, GUC once set   -> current_setting() returns ''
--   and ''::uuid RAISES, it does not become NULL
--
-- Without NULLIF you get zero rows on cold connections and 500s on warm ones:
-- intermittent, load-dependent, and very hard to reproduce. §2.3
CREATE OR REPLACE FUNCTION app.current_tenant() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(current_setting('app.tenant_id', true), '')::uuid
$$;
