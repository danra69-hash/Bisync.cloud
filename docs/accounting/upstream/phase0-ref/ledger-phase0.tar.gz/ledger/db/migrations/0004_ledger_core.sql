-- 0004 — the ledger core.
--
-- Every table here carries tenant_id, and every unique constraint and foreign
-- key is tenant-scoped. That is not belt-and-braces: constraints bypass RLS BY
-- DESIGN, so a global UNIQUE(number) is a covert channel — the error message
-- confirms another tenant owns that number and helpfully names the constraint.
-- Composite FKs including tenant_id make a cross-tenant reference structurally
-- impossible rather than merely unobserved. Blueprint §2.4, §3.2.

SET ROLE app_owner;

-- ─── Legal entity ────────────────────────────────────────────────────────────
CREATE TABLE app.entity (
  tenant_id     uuid NOT NULL,
  id            uuid NOT NULL DEFAULT app.uuid7(),
  code          text NOT NULL,
  name          text NOT NULL,
  func_currency char(3) NOT NULL REFERENCES ref.currency(code),
  country       char(2) NOT NULL,
  PRIMARY KEY (tenant_id, id),
  UNIQUE (tenant_id, code)
);

-- ─── Books. An entity may keep several in parallel (IFRS / tax / local GAAP).
-- ledger_id has to exist on day one; retrofitting a second book is a rewrite.
CREATE TABLE app.ledger (
  tenant_id uuid NOT NULL,
  id        uuid NOT NULL DEFAULT app.uuid7(),
  entity_id uuid NOT NULL,
  kind      text NOT NULL CHECK (kind IN ('primary','tax','ifrs','local_gaap','consolidation')),
  name      text NOT NULL,
  PRIMARY KEY (tenant_id, id),
  UNIQUE (tenant_id, entity_id, kind),
  FOREIGN KEY (tenant_id, entity_id) REFERENCES app.entity (tenant_id, id)
);

-- ─── Chart of accounts ───────────────────────────────────────────────────────
CREATE TABLE app.account (
  tenant_id      uuid NOT NULL,
  id             uuid NOT NULL DEFAULT app.uuid7(),
  code           text NOT NULL,
  name           text NOT NULL,
  type           text NOT NULL CHECK (type IN ('asset','liability','equity','income','expense')),
  normal_balance char(1) NOT NULL CHECK (normal_balance IN ('D','C')),
  is_control     boolean NOT NULL DEFAULT false,
  requires_cost_centre boolean NOT NULL DEFAULT false,
  PRIMARY KEY (tenant_id, id),
  UNIQUE (tenant_id, code)                      -- tenant-scoped, NOT global
);

-- ─── Fiscal periods ──────────────────────────────────────────────────────────
-- Periods are per ENTITY. The journal FK must therefore include entity_id, or a
-- line can point at a different entity's calendar. §3.6
CREATE TABLE app.fiscal_period (
  tenant_id  uuid NOT NULL,
  id         uuid NOT NULL DEFAULT app.uuid7(),
  entity_id  uuid NOT NULL,
  year       smallint NOT NULL,
  period_no  smallint NOT NULL CHECK (period_no BETWEEN 1 AND 12),
  start_date date NOT NULL,
  end_date   date NOT NULL,
  status     text NOT NULL DEFAULT 'future'
             CHECK (status IN ('future','open','closing','closed','hard_closed')),
  closed_at  timestamptz,
  PRIMARY KEY (tenant_id, id),
  UNIQUE (tenant_id, entity_id, id),            -- FK target for journal
  UNIQUE (tenant_id, entity_id, year, period_no),
  CHECK (end_date >= start_date),
  FOREIGN KEY (tenant_id, entity_id) REFERENCES app.entity (tenant_id, id)
);

CREATE INDEX ON app.fiscal_period (tenant_id, entity_id, start_date, end_date);

-- ─── Gapless document numbering ──────────────────────────────────────────────
-- A SEQUENCE cannot do this: nextval() is non-transactional by design, so a
-- rollback does not return the number. A locked counter row can. Serialisation
-- is per (tenant, series, year), so tenant A never blocks tenant B. §3.5
CREATE TABLE app.doc_counter (
  tenant_id   uuid NOT NULL,
  series      text NOT NULL,
  fiscal_year smallint NOT NULL,
  next_value  bigint NOT NULL DEFAULT 1 CHECK (next_value >= 1),
  PRIMARY KEY (tenant_id, series, fiscal_year)
);

-- ─── JOURNAL ─────────────────────────────────────────────────────────────────
CREATE TABLE app.journal (
  tenant_id       uuid NOT NULL,
  id              uuid NOT NULL DEFAULT app.uuid7(),
  entity_id       uuid NOT NULL,
  ledger_id       uuid NOT NULL,
  period_id       uuid NOT NULL,
  journal_type    text NOT NULL,
  doc_series      text NOT NULL,
  fiscal_year     smallint NOT NULL,
  doc_number      text,                     -- assigned at POST, never at draft
  effective_date  date NOT NULL,            -- accounting date -> drives period
  document_date   date NOT NULL,            -- original document date
  posted_at       timestamptz,              -- NULL = draft; non-NULL = sealed
  source_module   text NOT NULL,
  source_doc_id   uuid,
  reverses_id     uuid,                     -- storno link, set at creation
  idempotency_key text,
  payload_hash    bytea,
  prev_hash       bytea,
  row_hash        bytea,
  narration       text,
  created_by      uuid NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, id),
  UNIQUE (tenant_id, entity_id, id),
  FOREIGN KEY (tenant_id, entity_id) REFERENCES app.entity (tenant_id, id),
  FOREIGN KEY (tenant_id, ledger_id) REFERENCES app.ledger (tenant_id, id),
  FOREIGN KEY (tenant_id, entity_id, period_id)
      REFERENCES app.fiscal_period (tenant_id, entity_id, id),
  FOREIGN KEY (tenant_id, reverses_id) REFERENCES app.journal (tenant_id, id)
) PARTITION BY LIST (tenant_id);

CREATE TABLE app.journal_default PARTITION OF app.journal DEFAULT;

-- Deliberately NO reversed_by_id: it could only be written after the journal is
-- sealed, which mutates a sealed row and invalidates its hash. Derive the
-- back-link from reverses_id instead. §3.2
CREATE INDEX ON app.journal (tenant_id, reverses_id) WHERE reverses_id IS NOT NULL;
CREATE UNIQUE INDEX ON app.journal (tenant_id, doc_series, fiscal_year, doc_number)
  WHERE doc_number IS NOT NULL;
CREATE UNIQUE INDEX ON app.journal (tenant_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;
CREATE INDEX ON app.journal (tenant_id, period_id, posted_at);

-- ─── JOURNAL LINE ────────────────────────────────────────────────────────────
-- Wide, with dimensions denormalised onto the line (the SAP Universal Journal
-- shape). Reports must never join through documents to find a cost centre.
CREATE TABLE app.journal_line (
  tenant_id         uuid NOT NULL,
  journal_id        uuid NOT NULL,
  line_no           smallint NOT NULL CHECK (line_no > 0),
  account_id        uuid NOT NULL,
  direction         char(1) NOT NULL CHECK (direction IN ('D','C')),

  -- Integer minor units + explicit currency. Never floats, never Postgres
  -- `money` (locale-dependent, fixed at 2 decimals). Non-negative amount plus
  -- an explicit direction beats a signed amount: double-entry semantics stay
  -- visible and debits/credits index separately.
  txn_currency      char(3) NOT NULL REFERENCES ref.currency(code),
  txn_amount_minor  bigint  NOT NULL CHECK (txn_amount_minor >= 0),
  func_currency     char(3) NOT NULL REFERENCES ref.currency(code),
  func_amount_minor bigint  NOT NULL CHECK (func_amount_minor >= 0),
  fx_rate           numeric(20,10) CHECK (fx_rate IS NULL OR fx_rate > 0),
  fx_rate_date      date,
  fx_rate_type      text CHECK (fx_rate_type IN ('spot','average','closing','historical')),

  -- dimensions, on the line — never encoded in the account code string
  entity_id         uuid NOT NULL,
  period_id         uuid NOT NULL,
  cost_centre_id    uuid,
  project_id        uuid,
  department_id     uuid,
  partner_entity_id uuid,          -- trading partner -> IC elimination
  dimensions        jsonb NOT NULL DEFAULT '{}'::jsonb,
  cashflow_category text,          -- nullable now; enables direct method later
  effective_date    date NOT NULL, -- copied from journal for index locality
  narration         text,

  PRIMARY KEY (tenant_id, journal_id, line_no),
  FOREIGN KEY (tenant_id, journal_id) REFERENCES app.journal (tenant_id, id),
  FOREIGN KEY (tenant_id, account_id) REFERENCES app.account (tenant_id, id),
  FOREIGN KEY (tenant_id, entity_id)  REFERENCES app.entity  (tenant_id, id),
  -- FX fields travel together or not at all
  CHECK ( (fx_rate IS NULL AND fx_rate_date IS NULL AND fx_rate_type IS NULL)
       OR (fx_rate IS NOT NULL AND fx_rate_date IS NOT NULL AND fx_rate_type IS NOT NULL) ),
  CHECK ( txn_currency = func_currency OR fx_rate IS NOT NULL )
) PARTITION BY LIST (tenant_id);

CREATE TABLE app.journal_line_default PARTITION OF app.journal_line DEFAULT;

-- Every index leads with tenant_id. A bare (tenant_id) index is not enough when
-- there is a secondary predicate. RLS makes missing indexes far more likely,
-- because the predicate is invisible in application code. §2.6
CREATE INDEX ON app.journal_line (tenant_id, account_id, effective_date)
  INCLUDE (direction, func_amount_minor);
CREATE INDEX ON app.journal_line (tenant_id, entity_id, period_id, account_id);
-- btree_gin lets the GIN index lead with tenant_id like every other index.
-- A bare `USING gin (dimensions)` is a cross-tenant index: correct results
-- (RLS still filters) but every tenant scans every tenant's posting lists.
CREATE INDEX ON app.journal_line USING gin (tenant_id, dimensions);
CREATE INDEX ON app.journal_line USING brin (tenant_id, effective_date);

-- ─── Dimension dictionary ────────────────────────────────────────────────────
-- dim_hash must be decodable or you cannot filter or group by cost centre.
CREATE TABLE app.dimension_tuple (
  tenant_id uuid  NOT NULL,
  dim_hash  bytea NOT NULL,
  tuple     jsonb NOT NULL,
  PRIMARY KEY (tenant_id, dim_hash)
);

-- ─── PERIOD BALANCE — the trial-balance cube ─────────────────────────────────
-- Account level, no dimensions: low cardinality, and this is what serves the
-- trial balance and statutory financials. Both currency dimensions are carried
-- because one amount pair cannot serve both the FX revaluation sub-balance and
-- the functional-currency figures that must balance. §3.7
CREATE TABLE app.period_balance (
  tenant_id       uuid NOT NULL,
  entity_id       uuid NOT NULL,
  ledger_id       uuid NOT NULL,
  account_id      uuid NOT NULL,
  period_id       uuid NOT NULL,
  txn_currency    char(3) NOT NULL,
  opening_txn_dr  bigint NOT NULL DEFAULT 0,
  opening_txn_cr  bigint NOT NULL DEFAULT 0,
  period_txn_dr   bigint NOT NULL DEFAULT 0,
  period_txn_cr   bigint NOT NULL DEFAULT 0,
  opening_func_dr bigint NOT NULL DEFAULT 0,
  opening_func_cr bigint NOT NULL DEFAULT 0,
  period_func_dr  bigint NOT NULL DEFAULT 0,
  period_func_cr  bigint NOT NULL DEFAULT 0,
  is_frozen       boolean NOT NULL DEFAULT false,
  recompute_after timestamptz,
  PRIMARY KEY (tenant_id, entity_id, ledger_id, account_id, period_id, txn_currency)
);

-- Same grain plus dim_hash: management reporting and drilldown only. Never the
-- source of a statutory number — its cardinality approaches the line table once
-- tenants use the jsonb escape hatch.
CREATE TABLE app.period_balance_dim (
  LIKE app.period_balance INCLUDING DEFAULTS INCLUDING CONSTRAINTS,
  dim_hash bytea NOT NULL,
  PRIMARY KEY (tenant_id, entity_id, ledger_id, account_id, period_id, txn_currency, dim_hash)
);

-- ─── Transactional outbox ────────────────────────────────────────────────────
-- Side effects are enqueued in the SAME transaction as the posting. "The
-- journal committed but the task was lost" is not an acceptable failure mode in
-- a ledger. A relay process publishes from here. §6.3
CREATE TABLE app.outbox (
  tenant_id    uuid NOT NULL,
  id           uuid NOT NULL DEFAULT app.uuid7(),
  topic        text NOT NULL,
  payload      jsonb NOT NULL,
  dedupe_key   text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  attempts     smallint NOT NULL DEFAULT 0,
  PRIMARY KEY (tenant_id, id)
);
CREATE UNIQUE INDEX ON app.outbox (tenant_id, topic, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX ON app.outbox (tenant_id, created_at) WHERE published_at IS NULL;

-- ─── Audit trail ─────────────────────────────────────────────────────────────
-- The event codes mirror France's NF203 taxonomy (10/15 sequence changes,
-- 30 fiscal-year archiving, 50 period close, 60 year-end close, 90 integrity
-- flaw, 180 entry export). Adopting it now is cheap; it is a certification
-- blocker later. §5.5, §7.2
CREATE TABLE app.audit_event (
  tenant_id   uuid NOT NULL,
  id          uuid NOT NULL DEFAULT app.uuid7(),
  event_code  smallint NOT NULL,
  event_name  text NOT NULL,
  actor_id    uuid,
  object_type text,
  object_id   uuid,
  before      jsonb,
  after       jsonb,
  request_id  text,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, id)
);
CREATE INDEX ON app.audit_event (tenant_id, occurred_at DESC);
CREATE INDEX ON app.audit_event (tenant_id, object_type, object_id);

RESET ROLE;
