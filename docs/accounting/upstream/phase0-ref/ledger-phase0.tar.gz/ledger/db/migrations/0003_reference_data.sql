-- 0003 — global reference data. No tenant_id, therefore no RLS.
-- The CI schema gate allowlists this schema explicitly.

SET ROLE app_owner;

-- An amount is meaningless without its currency, and the minor-unit exponent is
-- NOT always 2. JPY/KRW/VND are 0; KWD/BHD/OMR/TND are 3. Hardcoding /100
-- anywhere in the codebase is a bug waiting for your first Japanese customer.
CREATE TABLE ref.currency (
  code        char(3) PRIMARY KEY,
  minor_unit  smallint NOT NULL CHECK (minor_unit BETWEEN 0 AND 4),
  name        text NOT NULL
);

INSERT INTO ref.currency (code, minor_unit, name) VALUES
  ('USD', 2, 'US Dollar'),
  ('EUR', 2, 'Euro'),
  ('GBP', 2, 'Pound Sterling'),
  ('MYR', 2, 'Malaysian Ringgit'),
  ('SGD', 2, 'Singapore Dollar'),
  ('JPY', 0, 'Yen'),
  ('KRW', 0, 'Won'),
  ('VND', 0, 'Dong'),
  ('KWD', 3, 'Kuwaiti Dinar'),
  ('BHD', 3, 'Bahraini Dinar'),
  ('OMR', 3, 'Rial Omani'),
  ('TND', 3, 'Tunisian Dinar');

-- FX rates need much more precision than amounts, and the direction convention
-- must be explicit — inverted-rate bugs are endemic. Global here for the
-- skeleton; in production tenants may override with their own rate sources.
CREATE TABLE ref.fx_rate (
  from_ccy  char(3) NOT NULL REFERENCES ref.currency(code),
  to_ccy    char(3) NOT NULL REFERENCES ref.currency(code),
  rate_date date    NOT NULL,
  rate_type text    NOT NULL CHECK (rate_type IN ('spot','average','closing','historical')),
  rate      numeric(20,10) NOT NULL CHECK (rate > 0),
  PRIMARY KEY (from_ccy, to_ccy, rate_date, rate_type)
);

GRANT SELECT ON ALL TABLES IN SCHEMA ref TO app_rw, app_reports;
GRANT INSERT, UPDATE ON ref.fx_rate TO app_rw;

RESET ROLE;
