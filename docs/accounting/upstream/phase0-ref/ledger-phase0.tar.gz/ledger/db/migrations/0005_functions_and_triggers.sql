-- 0005 — the invariants, enforced in the database.
--
-- Application-level checks are insufficient: one bad migration script or admin
-- action breaks the book forever, and the damage is discovered at audit.

SET ROLE app_owner;

-- ─────────────────────────────────────────────────────────────────────────────
-- Debits == credits. TWO distinct invariants, both required.
--
--   (a) per TRANSACTION currency  — the economic statement. A journal mixing
--       USD and EUR must balance within each currency separately; there is no
--       universal rate and cross-currency balancing makes historical rate
--       verification impossible.
--   (b) whole journal in FUNCTIONAL currency — what makes the trial balance
--       balance.
--
-- Grouping by func_currency would be a no-op: it is constant per entity.
--
-- DELETE is in the trigger event list deliberately. Without it, deleting a line
-- from an unposted journal in a LATER transaction leaves that journal
-- permanently unbalanced with no error. §3.3
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.assert_journal_balanced() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  v_tenant  uuid := COALESCE(NEW.tenant_id,  OLD.tenant_id);
  v_journal uuid := COALESCE(NEW.journal_id, OLD.journal_id);
  v_lines   int;
  v_ccy     char(3);
  v_delta   bigint;
  v_func    bigint;
BEGIN
  -- The whole journal may have been discarded; nothing to check.
  PERFORM 1 FROM app.journal j WHERE j.tenant_id = v_tenant AND j.id = v_journal;
  IF NOT FOUND THEN RETURN NULL; END IF;

  SELECT count(*) INTO v_lines
    FROM app.journal_line l WHERE l.tenant_id = v_tenant AND l.journal_id = v_journal;

  -- A zero-line journal never fires a FOR EACH ROW trigger at all, so this is
  -- necessarily enforced at post time instead (see app.post_journal).
  IF v_lines = 0 THEN RETURN NULL; END IF;

  -- (a) per transaction currency
  SELECT txn_currency, delta INTO v_ccy, v_delta FROM (
    SELECT txn_currency,
           sum(CASE direction WHEN 'D' THEN txn_amount_minor ELSE -txn_amount_minor END) AS delta
      FROM app.journal_line
     WHERE tenant_id = v_tenant AND journal_id = v_journal
     GROUP BY txn_currency
  ) q WHERE delta <> 0 LIMIT 1;

  IF FOUND THEN
    RAISE EXCEPTION
      'journal % is unbalanced in transaction currency %: debits - credits = %',
      v_journal, v_ccy, v_delta
      USING ERRCODE = 'check_violation';
  END IF;

  -- (b) whole journal, functional currency
  SELECT sum(CASE direction WHEN 'D' THEN func_amount_minor ELSE -func_amount_minor END)
    INTO v_func
    FROM app.journal_line
   WHERE tenant_id = v_tenant AND journal_id = v_journal;

  IF v_func <> 0 THEN
    RAISE EXCEPTION
      'journal % is unbalanced in functional currency: debits - credits = %',
      v_journal, v_func
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NULL;
END $$;

-- Constraint triggers CANNOT be FOR EACH STATEMENT, so an N-line journal runs N
-- aggregate scans. Measure against the p95 target; if it bites, memoise the
-- checked journal ids in a transaction-local set.
CREATE CONSTRAINT TRIGGER journal_balanced
  AFTER INSERT OR UPDATE OR DELETE ON app.journal_line
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION app.assert_journal_balanced();

-- ─────────────────────────────────────────────────────────────────────────────
-- Immutability. Corrections are new entries (reversal + re-post), never
-- UPDATEs. France's inaltérabilité, Germany's GoBD Unveränderbarkeit and
-- Spain's VERI*FACTU all converge on this.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.reject_sealed_line_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  v_posted timestamptz;
  v_row    app.journal_line := COALESCE(NEW, OLD);
BEGIN
  SELECT posted_at INTO v_posted
    FROM app.journal WHERE tenant_id = v_row.tenant_id AND id = v_row.journal_id;
  IF v_posted IS NOT NULL THEN
    RAISE EXCEPTION 'journal % is posted and immutable; reverse it instead',
      v_row.journal_id USING ERRCODE = 'check_violation';
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;

CREATE TRIGGER journal_line_immutable
  BEFORE UPDATE OR DELETE ON app.journal_line
  FOR EACH ROW EXECUTE FUNCTION app.reject_sealed_line_mutation();

-- Sealed journals: only a narrow set of columns may ever change after posting,
-- and in this skeleton that set is empty. Anything that genuinely needs to
-- mutate (e.g. an e-invoice clearance id) belongs in a side table excluded from
-- the canonical hash payload.
CREATE OR REPLACE FUNCTION app.reject_sealed_journal_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.posted_at IS NOT NULL THEN
    RAISE EXCEPTION 'journal % is posted and immutable', OLD.id
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER journal_immutable
  BEFORE UPDATE OR DELETE ON app.journal
  FOR EACH ROW EXECUTE FUNCTION app.reject_sealed_journal_mutation();

-- ─────────────────────────────────────────────────────────────────────────────
-- Period locking, enforced in the DB. Enforcing this only in application code
-- guarantees it will be bypassed by a data-fix script.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.assert_period_open() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE v_status text; v_start date; v_end date;
BEGIN
  SELECT status, start_date, end_date INTO v_status, v_start, v_end
    FROM app.fiscal_period
   WHERE tenant_id = NEW.tenant_id AND entity_id = NEW.entity_id AND id = NEW.period_id;

  IF v_status IS NULL THEN
    RAISE EXCEPTION 'no such period % for entity %', NEW.period_id, NEW.entity_id
      USING ERRCODE = 'foreign_key_violation';
  END IF;

  IF v_status <> 'open' THEN
    RAISE EXCEPTION 'period % is % and will not accept postings', NEW.period_id, v_status
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.effective_date < v_start OR NEW.effective_date > v_end THEN
    RAISE EXCEPTION 'effective_date % falls outside period % (% .. %)',
      NEW.effective_date, NEW.period_id, v_start, v_end
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END $$;

CREATE TRIGGER journal_period_open
  BEFORE INSERT ON app.journal
  FOR EACH ROW EXECUTE FUNCTION app.assert_period_open();

-- ─────────────────────────────────────────────────────────────────────────────
-- Gapless document numbering.
--
-- Upsert, NOT a bare UPDATE. A bare UPDATE matches zero rows for the first
-- document of a new (tenant, series, fiscal_year); the CTE then yields nothing,
-- the INSERT is a no-op, and THE TRANSACTION COMMITS SUCCESSFULLY. A fiscal
-- year rolls over and postings vanish with no error.
--
-- format()'s width flag pads with SPACES, not zeros: '%06s' yields
-- 'INV/2026/     1'. Use lpad() — this is a legally significant string.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.next_doc_number(
  p_tenant uuid, p_series text, p_year smallint, p_width int DEFAULT 6
) RETURNS text
LANGUAGE plpgsql AS $$
DECLARE v_n bigint;
BEGIN
  INSERT INTO app.doc_counter (tenant_id, series, fiscal_year, next_value)
  VALUES (p_tenant, p_series, p_year, 2)
  ON CONFLICT (tenant_id, series, fiscal_year)
  DO UPDATE SET next_value = app.doc_counter.next_value + 1
  RETURNING next_value - 1 INTO v_n;

  IF v_n IS NULL THEN
    RAISE EXCEPTION 'doc_counter upsert returned no row for (%, %, %)',
      p_tenant, p_series, p_year USING ERRCODE = 'internal_error';
  END IF;

  RETURN format('%s/%s/%s', p_series, p_year, lpad(v_n::text, p_width, '0'));
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- Post: seal the journal, assign the legal number, chain the hash, roll the
-- balance cube. Numbering happens LAST and only at post — drafts get UUIDs.
-- That eliminates abandoned drafts, the largest source of gaps, at the domain
-- level rather than the database level. §3.5
--
-- Never call an external service while holding the counter lock.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.post_journal(p_journal_id uuid, p_actor uuid)
RETURNS text
LANGUAGE plpgsql AS $$
DECLARE
  v_tenant uuid := app.current_tenant();
  j        app.journal;
  v_lines  int;
  v_number text;
  v_prev   bytea;
  v_hash   bytea;
  v_canon  text;
BEGIN
  IF v_tenant IS NULL THEN
    RAISE EXCEPTION 'no tenant context set' USING ERRCODE = 'insufficient_privilege';
  END IF;

  SELECT * INTO j FROM app.journal
   WHERE tenant_id = v_tenant AND id = p_journal_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'journal % not found', p_journal_id USING ERRCODE = 'no_data_found';
  END IF;
  IF j.posted_at IS NOT NULL THEN
    RAISE EXCEPTION 'journal % is already posted as %', j.id, j.doc_number
      USING ERRCODE = 'check_violation';
  END IF;

  -- A zero-line journal never fires the FOR EACH ROW balance trigger.
  SELECT count(*) INTO v_lines FROM app.journal_line
   WHERE tenant_id = v_tenant AND journal_id = j.id;
  IF v_lines < 2 THEN
    RAISE EXCEPTION 'journal % has % line(s); a posting needs at least two',
      j.id, v_lines USING ERRCODE = 'check_violation';
  END IF;

  -- Take the number LAST, after all validation. The counter row lock is held
  -- until COMMIT and serialises only this (tenant, series, year).
  v_number := app.next_doc_number(v_tenant, j.doc_series, j.fiscal_year);

  -- Hash chain per (tenant, series, fiscal_year). Cheap, and it turns "our data
  -- is immutable" from a claim into something demonstrable to an auditor.
  -- The counter lock above already serialises writers within the series.
  SELECT row_hash INTO v_prev
    FROM app.journal
   WHERE tenant_id = v_tenant AND doc_series = j.doc_series
     AND fiscal_year = j.fiscal_year AND posted_at IS NOT NULL
   ORDER BY doc_number DESC LIMIT 1;

  SELECT j.id::text || '|' || v_number || '|' || j.effective_date::text || '|' ||
         coalesce(string_agg(
           l.line_no::text || ':' || l.account_id::text || ':' || l.direction || ':' ||
           l.txn_currency || ':' || l.txn_amount_minor::text || ':' ||
           l.func_amount_minor::text, ',' ORDER BY l.line_no), '')
    INTO v_canon
    FROM app.journal_line l
   WHERE l.tenant_id = v_tenant AND l.journal_id = j.id;

  v_hash := digest(coalesce(v_prev, ''::bytea) || v_canon::bytea, 'sha256');

  -- posted_at is still NULL here, so the immutability trigger permits this.
  UPDATE app.journal
     SET doc_number = v_number,
         posted_at  = now(),
         prev_hash  = v_prev,
         row_hash   = v_hash
   WHERE tenant_id = v_tenant AND id = j.id;

  PERFORM app.roll_period_balance(v_tenant, j.id);

  INSERT INTO app.audit_event (tenant_id, event_code, event_name, actor_id,
                               object_type, object_id, after)
  VALUES (v_tenant, 10, 'journal.posted', p_actor, 'journal', j.id,
          jsonb_build_object('doc_number', v_number, 'lines', v_lines));

  RETURN v_number;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- Balance cube maintenance, inside the posting transaction. Fully rebuildable
-- from lines; app.detect_balance_drift() below is the mandatory safety net.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.roll_period_balance(p_tenant uuid, p_journal uuid)
RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_ledger uuid;
BEGIN
  SELECT ledger_id INTO v_ledger FROM app.journal
   WHERE tenant_id = p_tenant AND id = p_journal;

  INSERT INTO app.period_balance AS pb
    (tenant_id, entity_id, ledger_id, account_id, period_id, txn_currency,
     period_txn_dr, period_txn_cr, period_func_dr, period_func_cr)
  SELECT l.tenant_id, l.entity_id, v_ledger, l.account_id, l.period_id, l.txn_currency,
         sum(CASE l.direction WHEN 'D' THEN l.txn_amount_minor  ELSE 0 END),
         sum(CASE l.direction WHEN 'C' THEN l.txn_amount_minor  ELSE 0 END),
         sum(CASE l.direction WHEN 'D' THEN l.func_amount_minor ELSE 0 END),
         sum(CASE l.direction WHEN 'C' THEN l.func_amount_minor ELSE 0 END)
    FROM app.journal_line l
   WHERE l.tenant_id = p_tenant AND l.journal_id = p_journal
   GROUP BY l.tenant_id, l.entity_id, l.account_id, l.period_id, l.txn_currency
  ON CONFLICT (tenant_id, entity_id, ledger_id, account_id, period_id, txn_currency)
  DO UPDATE SET
     period_txn_dr  = pb.period_txn_dr  + EXCLUDED.period_txn_dr,
     period_txn_cr  = pb.period_txn_cr  + EXCLUDED.period_txn_cr,
     period_func_dr = pb.period_func_dr + EXCLUDED.period_func_dr,
     period_func_cr = pb.period_func_cr + EXCLUDED.period_func_cr;
END $$;

-- A balance cache that can silently drift in a ledger is a defect generator.
-- Run this nightly; on divergence, disable cache reads for that account and
-- page someone. Returns one row per divergence — empty means clean.
CREATE OR REPLACE FUNCTION app.detect_balance_drift(p_tenant uuid)
RETURNS TABLE (account_id uuid, period_id uuid, txn_currency char(3),
               cube_func_dr bigint, line_func_dr bigint,
               cube_func_cr bigint, line_func_cr bigint)
LANGUAGE sql STABLE AS $$
  WITH from_lines AS (
    SELECT l.account_id, l.period_id, l.txn_currency,
           sum(CASE l.direction WHEN 'D' THEN l.func_amount_minor ELSE 0 END) AS dr,
           sum(CASE l.direction WHEN 'C' THEN l.func_amount_minor ELSE 0 END) AS cr
      FROM app.journal_line l
      JOIN app.journal j ON j.tenant_id = l.tenant_id AND j.id = l.journal_id
     WHERE l.tenant_id = p_tenant AND j.posted_at IS NOT NULL
     GROUP BY 1,2,3
  ), from_cube AS (
    SELECT pb.account_id, pb.period_id, pb.txn_currency,
           sum(pb.period_func_dr) AS dr, sum(pb.period_func_cr) AS cr
      FROM app.period_balance pb WHERE pb.tenant_id = p_tenant
     GROUP BY 1,2,3
  )
  SELECT coalesce(c.account_id, l.account_id),
         coalesce(c.period_id,  l.period_id),
         coalesce(c.txn_currency, l.txn_currency),
         coalesce(c.dr,0), coalesce(l.dr,0), coalesce(c.cr,0), coalesce(l.cr,0)
    FROM from_cube c
    FULL OUTER JOIN from_lines l
      ON  l.account_id = c.account_id
      AND l.period_id  = c.period_id
      AND l.txn_currency = c.txn_currency
   WHERE coalesce(c.dr,0) <> coalesce(l.dr,0)
      OR coalesce(c.cr,0) <> coalesce(l.cr,0);
$$;

GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA app TO app_rw;
GRANT EXECUTE ON FUNCTION app.current_tenant(), app.detect_balance_drift(uuid) TO app_reports;

RESET ROLE;
